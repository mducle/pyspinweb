""" Main widget for Qt/GL rendering of magnetic crystal structures"""

import numpy as np
from PySide6.QtCore import QTimer, QPoint, Signal
from PySide6.QtGui import Qt, QKeyEvent, QImage, QSurfaceFormat
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL.GL import *
from PySide6.QtWidgets import QApplication

from pyspinw.gui.buffers import IntegerBuffer
from pyspinw.gui.camera import Camera
from pyspinw.gui.rendermodel import RenderModel
from pyspinw.gui.rendering.axes_shader import AxesShader
from pyspinw.gui.rendering.cell_shader import CellShader
from pyspinw.gui.rendering.id_shader import IDShader
from pyspinw.gui.rendering.models.arrow import Arrow
from pyspinw.gui.rendering.models.sphere import Sphere
from pyspinw.gui.rendering.models.tube import Tube

import logging

from pyspinw.gui.rendering.models.wrireframe_cube import WireframeCube
from pyspinw.gui.rendering.object_shader import ObjectShader
from pyspinw.gui.rendering.selectionmode import SelectionMode
from pyspinw.gui.rendering.selection_shader import SelectionShader
from pyspinw.gui.displayoptions import DisplayOptions
from pyspinw.util import rotation_matrix

logger = logging.Logger(__name__)

# Transforms for xyz arrows in axes viewport
_z_axis_mat = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, .5], [0, 0, 0, 1]], dtype=np.float32)
_y_axis_mat = np.array([[1, 0, 0, 0], [0, 0, 1, .5], [0, -1, 0, 0], [0, 0, 0, 1]], dtype=np.float32)
_x_axis_mat = np.array([[0, 0, 1, .5], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]], dtype=np.float32)

_selection_size = 0.2

class CrystalViewerWidget(QOpenGLWidget):
    """ Qt widget to show magnetic crystal structures """

    hoverChanged = Signal()
    selectionChanged = Signal()

    mouse_angle_sensitivity = 0.01
    mouse_move_sensitivity = 0.005
    mouse_zoom_sensitivity = 0.002
    min_view_radius = 0.01

    axes_size = 100
    axes_padding = 10

    def __init__(self,
                 render_model: RenderModel,
                 initial_rotation: np.ndarray | None = None,
                 initial_distance: float | None = None):

        super().__init__()

        self.initialised = False

        self.render_model = render_model

        self.display_options = DisplayOptions()

        self.camera = Camera()

        self.object_shader: ObjectShader | None = None
        self.selection_shader: SelectionShader | None = None

        # Set up antialiasing
        fmt = QSurfaceFormat()
        fmt.setVersion(4, 1)
        fmt.setProfile(QSurfaceFormat.CoreProfile)
        fmt.setSamples(4)
        self.setFormat(fmt)

        # View details
        self.view_origin = render_model.expanded.structure.unit_cell.centre
        self.view_rotation = np.eye(3) if initial_rotation is None else initial_rotation
        self.view_radius = 10.0 if initial_distance is None else initial_distance

        # These variables are used for selection / highlighting
        self.mouse_position: QPoint | None = None
        self.hover_ids: list[int] = []
        self.current_selection: list[int] = []
        self.last_hover_id = 0
        self.current_hover_id = 0

        # These variables are used for handling mouse dragging
        self.mouse_data: tuple[QPoint, Qt.MouseButton, int] | None= None
        self.mouse_rotation = np.eye(3)
        self.mouse_origin = np.array([0,0,0], dtype=float)

        # We want to be able to do hovering, and respond to key presses
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)



    def initializeGL(self):
        """ Qt override, set up the GL rendering """
        glEnable(GL_DEPTH_TEST)

        try:
            # Normal objects
            self.sphere= Sphere(3)
            self.selection_sphere = Sphere(3, padding=0.1)

            self.small_sphere = Sphere(3, 0.1)
            self.selection_small_sphere = Sphere(3, radius=0.1, padding=0.01)

            self.tube = Tube()
            self.selection_tube = Tube(padding=0.2)

            self.arrow = Arrow()
            self.selection_arrow = Arrow(padding=0.03, modify_ring=True)

            self.cube = WireframeCube()

            # Normal shaders
            self.object_shader = ObjectShader()
            self.selection_shader = SelectionShader()
            self.cell_shader = CellShader()

            # shader for axes
            self.axes_shader = AxesShader()

            # Shader used for object ID mapping
            self.id_shader = IDShader()

            # Framebuffer for ID rendering
            self.id_framebuffer = IntegerBuffer()


            self.angle = 0.0

            # Animation timer
            self.timer = QTimer()
            self.timer.timeout.connect(self.update)
            self.timer.start(16)

            self.initialised = True


        except Exception as e:
            logger.exception(e)

    def paintGL(self):
        """ Qt override, paints the GL canvas"""
        #
        # Normal painting, let Qt do its thing
        #

        if not self.initialised:
            self.initializeGL()
            return

        glBindFramebuffer(GL_FRAMEBUFFER, self.defaultFramebufferObject())
        dpr = self.devicePixelRatio()
        pw, ph = int(self.width() * dpr), int(self.height() * dpr)
        glViewport(0, 0, pw, ph)

        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glDisable(GL_BLEND)

        background_r, background_g, background_b = self.display_options.background_color
        glClearColor(background_r, background_g, background_b, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # Work out camera movement stuff

        compound_rotation = self.view_rotation @ self.mouse_rotation

        origin_world = self.view_origin + self.mouse_origin

        camera_world = origin_world + \
                       compound_rotation @ np.array([0, 0, self.view_radius], dtype=float)


        up_world = compound_rotation @ np.array([0,1,0], dtype=float)

        self.camera.position = tuple(camera_world)
        self.camera.up = tuple(up_world)
        self.camera.look_at = tuple(origin_world)

        # # Camera debug things
        #
        # scale = 0.03
        # for position, color in [([0,0,0], (1,0,0)),
        #                         ([origin_world, (0,1,0)]),
        #                         ([self.view_origin, (0,0,1)])]:
        #
        #     m = np.diag([scale, scale, scale, 1])
        #     v = np.array(position, dtype=np.float32)
        #
        #     m[:3, 3] = v
        #
        #     self.object_shader.model_matrix = m
        #     self.object_shader.object_color = color
        #     self.object_shader.use()
        #     self.sphere.render_triangles()

        # Set up colors for selection shaders
        self.selection_shader.selected_color = self.display_options.selected_color
        self.selection_shader.hover_color = self.display_options.hover_color
        self.selection_shader.selected_hover_color = self.display_options.selected_hover_color

        # Do actual the rendering

        spin_scale = 2 * self.display_options.atom_spin_scaling
        spin_scale_matrix = np.diag([spin_scale, spin_scale, spin_scale, 1])

        exchange_scale = 0.1 * self.display_options.exchange_scaling
        exchange_scaling = np.diag([exchange_scale, exchange_scale, 1, 1])
        exchange_selection_scale = ((1 + _selection_size)/1)*exchange_scale
        exchange_selection_scaling = np.diag([exchange_selection_scale, exchange_selection_scale, 1, 1])

        if self.object_shader is not None and self.selection_shader is not None:

            self.object_shader.camera = self.camera
            self.selection_shader.camera = self.camera

            # Sites
            if self.display_options.show_sites:


                for site in self.render_model.sites:

                    self.object_shader.object_color = self.display_options.default_site_color \
                        if site.color is None else site.color

                    if site.is_magnetic or self.display_options.show_nonmagnetic_atoms:

                        # TODO: This can be sped up
                        if site.render_id in self.hover_ids:
                            if site.render_id in self.current_selection:
                                mode = SelectionMode.SELECTED_HOVER
                            else:
                                mode = SelectionMode.HOVER

                        else:
                            if site.render_id in self.current_selection:
                                mode = SelectionMode.SELECTED
                            else:
                                mode = SelectionMode.NOT_SELECTED

                        show_arrow = site.is_magnetic and self.display_options.show_atoms_not_spins
                        render_object = self.arrow if show_arrow else self.small_sphere
                        selection_render_object = self.selection_arrow if show_arrow else self.selection_small_sphere

                        for model_matrix in site.model_matrices(self.display_options.prettify):
                            site_model_matrix = model_matrix @ spin_scale_matrix

                            # scale spheres by atom size
                            if not show_arrow:

                                s = site.radius
                                atomscale = np.diag([s, s, s, 1])
                                site_model_matrix = site_model_matrix @ atomscale

                            if mode != SelectionMode.NOT_SELECTED:

                                self.selection_shader.model_matrix = site_model_matrix
                                self.selection_shader.mode = mode
                                self.selection_shader.use()
                                selection_render_object.render_back()

                            self.object_shader.model_matrix = site_model_matrix
                            self.object_shader.use()
                            render_object.render_triangles()

            # Exchanges
            if self.display_options.show_exchanges:

                for exchange in self.render_model.exchanges:

                    self.object_shader.object_color = \
                        self.display_options.default_exchange_color \
                            if exchange.color is None else exchange.color

                    if exchange.render_id in self.hover_ids:
                        if exchange.render_id in self.current_selection:
                            mode = SelectionMode.SELECTED_HOVER
                        else:
                            mode = SelectionMode.HOVER

                    else:
                        if exchange.render_id in self.current_selection:
                            mode = SelectionMode.SELECTED
                        else:
                            mode = SelectionMode.NOT_SELECTED

                    for model_matrix in exchange.model_matrices(self.display_options.prettify):

                        if mode != SelectionMode.NOT_SELECTED:
                            exchange_model_matrix = model_matrix @ exchange_selection_scaling
                            self.selection_shader.model_matrix = exchange_model_matrix
                            self.selection_shader.mode = mode
                            self.selection_shader.use()
                            self.selection_tube.render_back()

                        exchange_model_matrix = model_matrix @ exchange_scaling
                        self.object_shader.model_matrix = exchange_model_matrix
                        self.object_shader.use()
                        self.tube.render_triangles()



        # Draw the supercell
        if self.display_options.show_supercell:
            supercell_matrix = np.eye(4, dtype=np.float32)
            supercell_matrix[:3, :3] = self.render_model.expanded.structure.unit_cell._xyz.T


            self.cell_shader.model_matrix = supercell_matrix
            self.cell_shader.camera = self.camera

            self.cell_shader.use()
            self.cube.render_wireframe()

        # Render unit cells
        if self.display_options.show_unit_cell:
            unit_cell_transform = np.eye(4, dtype=np.float32)
            unit_cell_transform[:3,:3] = self.render_model.hamiltonian.structure.unit_cell._xyz.T

            self.cell_shader.camera = self.camera

            for offset in self.render_model.hamiltonian.structure.supercell.cells():
                translation_matrix = np.eye(4, dtype=np.float32)
                translation_matrix[:3, 3] = offset.vector

                self.cell_shader.model_matrix = unit_cell_transform @ translation_matrix

                self.cell_shader.use()
                self.cube.render_wireframe()

        #
        # Corner viewport for axes
        #

        if self.display_options.show_cartesian_axes:

            # Save state
            saved_depth_test = glIsEnabled(GL_DEPTH_TEST)
            glDisable(GL_DEPTH_TEST)

            # Axes viewport
            glViewport(
                int(self.axes_padding * dpr),
                int(self.axes_padding * dpr),
                int(self.axes_size * dpr),
                int(self.axes_size * dpr),
            )

            self.axes_shader.camera = self.camera

            # render x
            self.axes_shader.object_color = 1, 0, 0
            self.axes_shader.model_matrix = _x_axis_mat
            self.axes_shader.use()
            self.arrow.render_triangles()

            # render y
            self.axes_shader.object_color = 0, 1, 0
            self.axes_shader.model_matrix = _y_axis_mat
            self.axes_shader.use()
            self.arrow.render_triangles()

            # render z
            self.axes_shader.object_color = 0, 0, 1
            self.axes_shader.model_matrix = _z_axis_mat
            self.axes_shader.use()
            self.arrow.render_triangles()


            # Restore state
            glViewport(0, 0, pw, ph)
            if saved_depth_test:
                glEnable(GL_DEPTH_TEST)

        #
        # Other corner viewport for lattice axes
        #

        if self.display_options.show_lattice_axes:

            # Save state
            saved_depth_test = glIsEnabled(GL_DEPTH_TEST)
            glDisable(GL_DEPTH_TEST)

            # Lattice axes viewport
            glViewport(
                int((self.width() - self.axes_size - self.axes_padding) * dpr),
                int(self.axes_padding * dpr),
                int(self.axes_size * dpr),
                int(self.axes_size * dpr)
            )

            self.axes_shader.camera = self.camera

            if self.display_options.orthogonal_lattice_axes:
                transforms = self.render_model.unit_cell_orthobasis_transforms
            else:
                transforms = self.render_model.unit_cell_axes_transforms

            # render a
            self.axes_shader.object_color = 0.8, 0.4, 0 # Red -> Orange
            self.axes_shader.model_matrix = transforms[0]
            self.axes_shader.use()
            self.arrow.render_triangles()

            # render b
            self.axes_shader.object_color = 0.6, 0.8, 0 # Green -> Yellow
            self.axes_shader.model_matrix = transforms[1]
            self.axes_shader.use()
            self.arrow.render_triangles()

            # render c
            self.axes_shader.object_color = 0.7, 0.3, 0.9 # Blue -> pink
            self.axes_shader.model_matrix = transforms[2]
            self.axes_shader.use()
            self.arrow.render_triangles()

            # Restore state

            if saved_depth_test:
                glEnable(GL_DEPTH_TEST)

            glViewport(0, 0, pw, ph)


        #
        # ID framebuffer
        #

        self.id_framebuffer.use(
            int(self.width()*dpr),
            int(self.height()*dpr))

        if self.id_shader is not None:

            self.id_shader.camera = self.camera

            # Sites
            if self.display_options.show_sites:

                for site in self.render_model.sites:

                    if site.is_magnetic or self.display_options.show_nonmagnetic_atoms:

                        render_object = self.arrow if site.is_magnetic else self.small_sphere

                        for model_matrix in site.model_matrices(self.display_options.prettify):

                            site_model_matrix = model_matrix @ spin_scale_matrix

                            self.id_shader.model_matrix = site_model_matrix
                            self.id_shader.id_value = site.render_id
                            self.id_shader.use()
                            render_object.render_triangles()

            # Exchanges
            if self.display_options.show_exchanges:

                for exchange in self.render_model.exchanges:
                    for model_matrix in exchange.model_matrices(self.display_options.prettify):
                        self.id_shader.id_value = exchange.render_id
                        self.id_shader.model_matrix = model_matrix @ exchange_scaling
                        self.id_shader.use()
                        self.tube.render_triangles()



        #
        # Calculate the object for the mouse over, and set its hover state
        #

        if self.mouse_position is not None:

            id = np.zeros((1,), dtype=np.uint32) # Buffer to set data in

            x = int(self.mouse_position.x() * dpr)
            y = int((self.height() - self.mouse_position.y()) * dpr)

            glReadPixels(
                x, y,
                1, 1,
                GL_RED_INTEGER,
                GL_UNSIGNED_INT,
                id
            )

            self.current_hover_id = int(id[0])
            if id != 0:
                self.hover_ids = [self.current_hover_id]
            else:
                self.hover_ids = []

            if self.last_hover_id != self.current_hover_id:
                self.hoverChanged.emit()

            self.last_hover_id = id

    def snapshot(self) -> np.ndarray:
        """ Get the data from the current frame """
        qimage = self.grabFramebuffer()
        qimage = qimage.convertToFormat(QImage.Format.Format_RGBA8888)

        ptr = qimage.bits()
        arr = np.frombuffer(ptr, dtype=np.uint8)
        arr = arr.reshape(qimage.height(), qimage.width(), 4)

        return arr.copy()


    def resizeGL(self, w, h):
        """ Qt override, called when window is resized """
        self.camera.horizontal_pixels = w
        self.camera.vertical_pixels = h
        dpr = self.devicePixelRatio()
        glViewport(0, 0, int(w * dpr), int(h * dpr))


    def reset_view(self):
        """ Reset the view to default """
        self.view_origin = self.render_model.expanded.structure.unit_cell.centre
        self.view_rotation = np.eye(3)
        self.view_radius = 10.0

    def click_on_element(self, index: int, shift: bool):
        """ Response to clicking on an element """
        if index == 0:
            if not shift:
                self.current_selection = []
                self.selectionChanged.emit()

        else:
            if not shift:
                self.current_selection = [index]
            else:
                self.current_selection.append(index)

            self.selectionChanged.emit()

    def mousePressEvent(self, event):
        """ Qt override, called on mouse press"""
        if self.mouse_data is None:
            self.mouse_data = event.position(), event.button(), self.hover_ids

            if event.button() == Qt.MouseButton.LeftButton:
                self.mouse_rotation = np.eye(3)

            elif event.button() == Qt.MouseButton.RightButton:
                self.mouse_rotation = np.eye(3)
                self.mouse_origin = np.zeros((3, ), dtype=float)

    def mouseMoveEvent(self, event):
        """Qt override, called on mouse movement"""
        self.mouse_position = event.position()

        if self.mouse_data is not None:
            start, button, _ = self.mouse_data
            end = event.position()

            dx = end.x() - start.x()
            dy = end.y() - start.y()

            if button == Qt.MouseButton.LeftButton:
                self.mouse_rotation = \
                    rotation_matrix(-self.mouse_angle_sensitivity*dx, (0, 1, 0)) @ \
                     rotation_matrix(-self.mouse_angle_sensitivity*dy, (1, 0, 0))


            if button == Qt.MouseButton.RightButton:
                r = self.view_rotation
                self.mouse_origin = r @ np.array([
                    -self.mouse_move_sensitivity*dx,
                    self.mouse_move_sensitivity*dy,
                    0.0])

    def mouseReleaseEvent(self, event):
        """ Qt override, called on mouse up"""
        if event.button() == Qt.MouseButton.LeftButton:

            start, button, _ = self.mouse_data
            end = event.position()

            dx = end.x() - start.x()
            dy = end.y() - start.y()

            if dx*dx + dy*dy < 100:

                modifiers = QApplication.keyboardModifiers()
                shift = modifiers == Qt.ShiftModifier

                self.click_on_element(self.current_hover_id, shift)

        self.mouse_data = None

        self.view_rotation =  self.view_rotation @ self.mouse_rotation
        self.view_origin = self.mouse_origin + self.view_origin

        self.mouse_rotation = np.eye(3, dtype=float)
        self.mouse_origin = np.zeros((3, ), dtype=float)

    def wheelEvent(self, event):
        """ Qt override, called when scroll wheel moves """
        self.view_radius *= 2**(self.mouse_zoom_sensitivity * event.angleDelta().y())

        if self.view_radius < self.min_view_radius:
            self.view_radius = self.min_view_radius

    def leaveEvent(self, event):
        """ Qt override, mouse leaves widget"""
        self.mouse_position = None
        event.accept()

