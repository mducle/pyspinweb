""" MATLAB style syntax module """
