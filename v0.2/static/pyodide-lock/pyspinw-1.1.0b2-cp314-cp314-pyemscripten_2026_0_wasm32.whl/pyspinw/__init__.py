"""pySpinW: Spin Hamiltonian calculations in Python.

SpinW is a Python library that can plot and numerically simulate
magnetic structures and excitations.
"""


from pyspinw.site import Site
from pyspinw.sitemeta import SiteMetadata
from pyspinw.symmetry.unitcell import UnitCell
from pyspinw.structure import Structure
from pyspinw.anisotropy import Anisotropy, AxisMagnitudeAnisotropy
from pyspinw.exchange import HeisenbergExchange, DiagonalExchange, XYExchange, IsingExchange, DMExchange
from pyspinw.hamiltonian import Hamiltonian

from pyspinw.exchangegroup import NoDirectionalityFilter, InPlaneFilter, InDirectionFilter, BiDirectionFilter

from pyspinw.interface import (
    generate_sites, propagation_vectors, rotation_supercell, helical_supercell, summation_supercell, get_spacegroup,
    filter, generate_exchanges, axis_anisotropies, matrix_anisotropies, generate_helical_structure, generate_structure,
    load_tb2j)

from pyspinw.symmetry.supercell import (
    SummationSupercell, RotationSupercell, TransformationSupercell, TiledSupercell, DirectSupercell,
    PropagationVector, CommensuratePropagationVector, RotationTransform)

from pyspinw.sample import SingleCrystal, Multidomain, CrystalDomain, Twin, Powder, ScalingMethod
from pyspinw.path import Path, Path1D, Slice

from pyspinw.calculations.spherical_integration import SphericalPointGeneratorType
from pyspinw.gui import view, snapshot

from pyspinw.gui.displayoptions import DisplayOptions

from pyspinw.units import CoordsUnits, IntensityUnits

from pyspinw.cif import load_cif
from pyspinw.serialisation import load as load_spw, save
from pyspinw.loading import load

from pyspinw.demo import demo_viewer, demo_chains
from pyspinw.demo import run_demos as demos

__all__ = [
    # site
    "Site",
    "SiteMetadata",

    # anisotropy
    "Anisotropy",
    "AxisMagnitudeAnisotropy",

    # exchanges
    "HeisenbergExchange",
    "DiagonalExchange",
    "XYExchange",
    "IsingExchange",
    "DMExchange",

    # filters
    "NoDirectionalityFilter",
    "InPlaneFilter",
    "InDirectionFilter",
    "BiDirectionFilter",

    # Loading and Saving
    'load_tb2j',
    'load_cif',
    'load_spw',
    'load',
    'save',

    # structures / hamiltonian
    "Structure",
    "Hamiltonian",

    # symmetry
    "UnitCell",

    # units
    "CoordsUnits",
    "IntensityUnits",

    # interface functions
    "propagation_vectors",
    "rotation_supercell",
    "helical_supercell",
    "summation_supercell",
    "get_spacegroup",
    "filter",
    "generate_exchanges",
    "axis_anisotropies",
    "matrix_anisotropies",
    "generate_sites",
    "generate_exchanges",
    "generate_structure",
    "generate_helical_structure",

    # supercells
    "TiledSupercell",
    "DirectSupercell",
    "SummationSupercell",
    "RotationSupercell",
    "TransformationSupercell",
    "RotationTransform",
    "PropagationVector",
    "CommensuratePropagationVector",

    # sample
    "SingleCrystal",
    "Multidomain",
    "CrystalDomain",
    "Twin",
    "Powder",
    "ScalingMethod",

    # Point generators
    "SphericalPointGeneratorType",

    # path
    "Path",
    "Path1D",
    "Slice",

    # viewer
    "view",
    "snapshot",
    "DisplayOptions",

    # demo
    "demos",
    "demo_viewer",
    "demo_chains",
]
