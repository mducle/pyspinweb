"""Exchange terms between lattice sites."""
from dataclasses import dataclass
from typing import Optional

import numpy as np

from pyspinw.cell_offsets import CellOffsetCoercible, CellOffset
from pyspinw.checks import check_sizes
from pyspinw.exchangemetadata import ExchangeMetadata
from pyspinw.serialisation import SPWSerialisationContext, SPWSerialisable, numpy_serialise, \
    expects_keys, numpy_deserialise, SPWDeserialisationContext
from pyspinw.site import Site
from pyspinw.symmetry.operations import SpaceOperation
from pyspinw.symmetry.unitcell import UnitCell
from pyspinw.tolerances import tolerances
from pyspinw.util import triple_product_matrix, is_diagonal

_exchange_id_counter = -1
def _generate_unique_exchange_id():
    """Generate a unique ID for each exchange currently loaded.

    Returns
    -------
    int
        Unique integer identifier for the exchange.
    """
    global _exchange_id_counter # noqa: PLW0603
    _exchange_id_counter += 1
    return _exchange_id_counter

@dataclass
class ExchangeBaseDeserialisation:
    """Hold basic properties of an exchange term.

    Used during serialisation, not a user facing function

    Parameters
    ----------
    name : str
        Name of the exchange term.
    site_1 : Site
        First lattice site in the exchange term.
    site_2 : Site
        Second lattice site in the exchange term.
    cell_offset : CellOffset
        Offset between the unit cells containing the two sites.
    metadata : ExchangeMetadata
        Metadata attached to the exchange term.
    """

    name: str
    """Name of the exchange term."""
    site_1: Site
    """First lattice site in the exchange term."""
    site_2: Site
    """Second lattice site in the exchange term."""
    cell_offset: CellOffset
    """Offset between the unit cells containing the two sites."""
    metadata: ExchangeMetadata
    """Metadata attached to the exchange term."""


class Exchange(SPWSerialisable):
    """Represent an exchange term between two lattice sites.

    Parameters
    ----------
    site_1 : Site
        First lattice site in the exchange term.
    site_2 : Site
        Second lattice site in the exchange term.
    cell_offset : CellOffsetCoercible
        Offset between the unit cells containing the two sites.
    exchange_matrix : (3, 3) numpy.ndarray
        3x3 matrix defining the exchange interaction.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of (float, float, float), optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.

    Attributes
    ----------
    metadata : ExchangeMetadata
        Metadata attached to the exchange term.
    """

    serialisation_name = "exchange"

    @check_sizes(exchange_matrix=(3,3))
    def __init__(self,
                 site_1: Site,
                 site_2: Site,
                 cell_offset: CellOffsetCoercible,
                 exchange_matrix: np.ndarray,
                 name: str = "",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):

        self._name = name
        self._site_1 = site_1
        self._site_2 = site_2
        self._cell_offset = CellOffset.coerce(cell_offset)
        self._exchange_matrix = exchange_matrix

        self._unique_id = _generate_unique_exchange_id()
        self.metadata = ExchangeMetadata() if metadata is None else metadata

        if color is not None:
            self.metadata.color = color


    exchange_type = "General"
    parameters: list[str] = []
    parameter_defaults: list[float] = []
    short_string = "M"


    @property
    def name(self):
        """Name of this exchange."""
        return self._name

    @property
    def unique_id(self) -> int:
        """Unique identifier for this exchange."""
        return self._unique_id

    @property
    def site_1(self):
        """First site in the exchange term."""
        return self._site_1

    @property
    def site_2(self):
        """Second site in the exchange term."""
        return self._site_2

    @property
    def cell_offset(self):
        """Offset between unit cells containing sites 1 and 2."""
        return self._cell_offset

    @property
    def exchange_matrix(self) -> np.ndarray:
        r"""The exchange matrix for this exchange.

        If :math:`H` is the energy contribution for this exchange,
        :math:`\mathbf{S}_i` and :math:`\mathbf{S}_j` are the spin states,
        and :math:`M` is the exchange matrix, then

        .. math::

            H = \mathbf{S}_i^T M \mathbf{S}_j.
        """
        return self._exchange_matrix

    @property
    def lattice_vector(self):
        """Vector from site 1 to site 2 in lattice coordinates."""
        return self.cell_offset.vector + self._site_2.ijk - self._site_1.ijk

    def vector(self, unit_cell: UnitCell):
        """Return the vector from site 1 to site 2 in Cartesian coordinates.

        Parameters
        ----------
        unit_cell : UnitCell
            Unit cell used to convert lattice coordinates to Cartesian coordinates.

        Returns
        -------
        numpy.ndarray
            Vector from site 1 to site 2 in Cartesian coordinates.
        """
        return unit_cell.lattice_units_to_cartesian(self.lattice_vector)

    def distance(self, unit_cell: UnitCell):
        """Return the distance between site 1 and site 2 in Cartesian coordinates.

        Parameters
        ----------
        unit_cell : UnitCell
            Unit cell used to convert lattice coordinates to Cartesian coordinates.

        Returns
        -------
        float
            Distance between site 1 and site 2 in Cartesian coordinates.
        """
        return np.sqrt(np.sum(self.vector(unit_cell)**2))

    def _base_serialisation(self, context: SPWSerialisationContext):
        """Serialise base properties of the exchange term.

        Parameters
        ----------
        context : SPWSerialisationContext
            Serialisation context.

        Returns
        -------
        dict
            Serialised dictionary of base exchange properties.
        """
        return {
            "name": self.name,
            "site_1": self._site_1._serialise(context),
            "site_2": self._site_2._serialise(context),
            "cell_offset": self._cell_offset._serialise(context),
            "metadata": self.metadata._serialise(context)
        }

    def generalise(self):
        """Create a new exchange that is the most general kind, (`Exchange`).

        Returns
        -------
        Exchange
            General ``Exchange`` instance with the same parameters and matrix.
        """
        return Exchange(name=self.name,
                        site_1=self.site_1,
                        site_2=self.site_2,
                        cell_offset=self.cell_offset,
                        exchange_matrix=self.exchange_matrix,
                        metadata=self.metadata)

    def specialise(self):
        """Get the most specific exchange class available that fits this exchange.

        Returns
        -------
        Exchange
            Most specific ``Exchange`` subclass instance that represents this exchange.
        """
        return specialise_exchange(self)

    @check_sizes(exchange_matrix=(3,3), force_numpy=True, allow_nones=True)
    def updated(self,
                site_1 : Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                exchange_matrix: np.ndarray | None = None,
                metadata: ExchangeMetadata | None = None):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        exchange_matrix : (3, 3) numpy.ndarray, optional
            Replacement exchange matrix. If omitted, the current matrix is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        Exchange
            New ``Exchange`` instance with the specified fields updated.
        """
        return Exchange(
            site_1=self.site_1 if site_1 is None else site_1,
            site_2=self.site_2 if site_2 is None else site_2,
            cell_offset=self.cell_offset if cell_offset is None else cell_offset,
            name=self.name if name is None else name,
            exchange_matrix=self.exchange_matrix if exchange_matrix is None else exchange_matrix,
            metadata=self.metadata.copy() if metadata is None else metadata.copy())

    @staticmethod
    @expects_keys("name, site_1, site_2, cell_offset")
    def _base_deserialisation(json, context: SPWSerialisationContext):
        """Deserialise base properties of an exchange term.

        Parameters
        ----------
        json : dict
            Serialised dictionary containing base exchange properties.
        context : SPWSerialisationContext
            Deserialisation context.

        Returns
        -------
        ExchangeBaseDeserialisation
            Container holding the deserialised base exchange properties.
        """
        return ExchangeBaseDeserialisation(
            name=json["name"],
            site_1=Site._deserialise(json["site_1"], context),
            site_2=Site._deserialise(json["site_2"], context),
            cell_offset=CellOffset._deserialise(json["cell_offset"], context),
            metadata=ExchangeMetadata._deserialise(json["metadata"], context)
        )

    def _serialise(self, context: SPWSerialisationContext) -> dict:
        return {
            "type": self.exchange_type.lower(),
            "data": self._exchange_serialise(context)
        }

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        """Serialise exchange-specific data to a dictionary.

        Parameters
        ----------
        context : SPWSerialisationContext
            Serialisation context.

        Returns
        -------
        dict
            Dictionary containing the serialised exchange data.
        """
        json = self._base_serialisation(context)
        json["matrix"] = numpy_serialise(self._exchange_matrix)
        return json

    @staticmethod
    @expects_keys("type, data")
    def _deserialise(json: dict, context: SPWDeserialisationContext):
        type_name = json["type"]
        return lowercase_exchange_lookup[type_name]._exchange_deserialise(json["data"], context)


    @staticmethod
    @expects_keys("matrix")
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        """Deserialise an ``Exchange`` instance from a data dictionary.

        Parameters
        ----------
        data : dict
            Dictionary containing serialised exchange data.
        context : SPWSerialisationContext
            Deserialisation context.

        Returns
        -------
        Exchange
            Deserialised ``Exchange`` instance.
        """
        base = Exchange._base_deserialisation(data, context)

        return Exchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            exchange_matrix=numpy_deserialise(data["matrix"]),
            metadata=base.metadata)

    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        Returns
        -------
        bool
            ``True`` if the exchange matrix is symmetric within tolerance, ``False``
            otherwise.
        """
        return np.all(np.abs(self.exchange_matrix - self.exchange_matrix.T) < tolerances.IS_ZERO_TOL)

    def _obeys_symmetry(self,
                        unit_cell: UnitCell,
                        identity_operations: set[SpaceOperation],
                        inversion_operations: set[SpaceOperation]) -> bool:
        """Main logic for symmetry checking.

        Parameters
        ----------
        unit_cell : UnitCell
            Unit cell of the structure.
        identity_operations : set of SpaceOperation
            Symmetry operations that map the site pair to itself in the same order.
        inversion_operations : set of SpaceOperation
            Symmetry operations that swap the two sites in the pair.

        Returns
        -------
        bool
            ``True`` if the exchange matrix obeys the given symmetry operations,
            ``False`` otherwise.
        """
        # We want the exchange matrix in lattice units
        exchange_matrix = unit_cell._xyz_spins @ self._exchange_matrix @ unit_cell._xyz_spins.T
        # exchange_matrix = unit_cell._xyz_spins_inv @ self._exchange_matrix @ unit_cell._xyz_spins_inv.T
        # exchange_matrix = self._exchange_matrix

        # print(unit_cell._xyz_inv)
        # print(unit_cell._xyz_spins_inv)
        # print("Exchange matrix in lattice")
        # print(exchange_matrix)

        for operation in identity_operations:
            if not operation.symmorphic:
                continue


            # print("Operation matrix")
            # print(operation.point_operation_matrix)
            # print("Inverse operation matrix")
            # print(operation.inverse_point_operation_matrix)

            transformed = operation.point_operation_matrix @ exchange_matrix @ operation.inverse_point_operation_matrix

            if not np.allclose(exchange_matrix, transformed):

                # print(f"Failed on operation {operation}")
                return False

        exchange_matrix_T = self._exchange_matrix.T
        for operation in inversion_operations:
            if not operation.symmorphic:
                continue
            #
            # print("Operation matrix")
            # print(operation.point_operation_matrix)
            # print("Inverse operation matrix")
            # print(operation.inverse_point_operation_matrix)

            transformed = operation.point_operation_matrix @ exchange_matrix @ operation.inverse_point_operation_matrix

            # print("Transformed")
            # print(transformed)
            if not np.allclose(exchange_matrix_T, transformed):

                # print(f"Failed on operation {operation}")

                return False

        return True

    def obeys_symmetry(self, structure: "Structure") -> bool:
        """Check that this exchange is consistent with the symmetry group.

        Parameters
        ----------
        structure : Structure
            Crystal structure defining the unit cell and space group.

        Returns
        -------
        bool
            ``True`` if the exchange is invariant under the symmetry operations
            of ``structure``, ``False`` otherwise.
        """
        spacegroup = structure.spacegroup
        unit_cell = structure.unit_cell

        # Checking is easier than finding the list of symmetry groups
        identity_operations, inversion_operations = spacegroup.operations_on_single_site_pairs(self.site_1, self.site_2)
        return self._obeys_symmetry(unit_cell, identity_operations, inversion_operations)

    def symmetry_copy(self,
                      structure: "Structure",
                      site_1: Site,
                      site_2: Site,
                      cell_offset: CellOffsetCoercible = (0,0,0)) -> "Exchange":
        """Copy this exchange using symmetry operations.

        Parameters
        ----------
        structure : Structure
            Crystal structure defining the unit cell and space group.
        site_1 : Site
            First target lattice site.
        site_2 : Site
            Second target lattice site.
        cell_offset : CellOffsetCoercible, optional
            Unit-cell offset for the copied exchange. Default is ``(0, 0, 0)``.

        Returns
        -------
        Exchange
            New ``Exchange`` instance mapped to ``(site_1, site_2)`` by symmetry.

        Raises
        ------
        ValueError
            If this exchange does not obey the symmetry constraints of ``structure``,
            or if ``(site_1, site_2)`` is not related to the original site pair by
            symmetry.

        Notes
        -----
        There might be more than one symmetry operation that maps the pair of sites;
        however, the effect on the exchange should be the same for all these
        operations, meaning an arbitrary matching operation can be chosen when the
        exchange obeys the symmetry constraints.
        """
        spacegroup = structure.spacegroup
        unit_cell = structure.unit_cell

        if self.obeys_symmetry(structure):
            # find the operations that map the pairs

            pair_operations = spacegroup.operations_between_pairs(
                (self.site_1, self.site_2),
                (site_1, site_2))

            if len(pair_operations) == 0:
                raise ValueError("New points are not related to the original by symmetry")

            # Pick one element for the transformation
            space_operation = next(iter(pair_operations))
            point_operation = space_operation.point_operation_in_cartesian(unit_cell)
            new_matrix = point_operation @ self._exchange_matrix @ point_operation.T

            return Exchange(site_1, site_2,
                            exchange_matrix=new_matrix,
                            name=f"{self.name} [{space_operation.text_form}]",
                            cell_offset=CellOffset.coerce(cell_offset))

        else:
            raise ValueError("Exchange does not obey symmetry constraints, cannot use symmetry to copy")

    def symmetry_fill(self,
                      structure: "Structure",
                      include_original=False,
                      specialisation_rounding_exponent: int | None = tolerances.SPECIALISE_ROUNDING_EXPONENT
                      ) -> list["Exchange"]:
        """Make multiple copies of this exchange so that symmetry is satisfied.

        Parameters
        ----------
        structure : Structure
            Crystal structure defining the unit cell, sites, and space group.
        include_original : bool, optional
            Whether to include this original exchange in the returned list.
            Default is ``False``.
        specialisation_rounding_exponent : int, optional
            Decimal exponent used to round exchange matrix entries when specialising
            generated exchanges, or ``None`` for no rounding. Default is
            ``tolerances.SPECIALISE_ROUNDING_EXPONENT``.

        Returns
        -------
        list of Exchange
            Symmetry-equivalent exchanges generated across the structure, specialised
            to the narrowest applicable ``Exchange`` subclass.

        Raises
        ------
        ValueError
            If this exchange does not obey the symmetry constraints of ``structure``.
        """
        # Get the symmetry related sites

        if not self.obeys_symmetry(structure):
            raise ValueError(f"{self} does not obey symmetry constraints of {structure.spacegroup}, "
                             f"cannot use symmetry to copy")

        unit_cell: UnitCell = structure.unit_cell

        site_1_related = structure.symmetry_related(self.site_1)
        site_2_related = structure.symmetry_related(self.site_2)

        # Go through all possible pairs, and see if they have any symmetry operations relating them
        symmetry_related: list[tuple[Site, Site, list[SpaceOperation]]] = []
        for site_1, site_1_ops in site_1_related:
            for site_2, site_2_ops in site_2_related:
                shared_ops = site_1_ops.intersection(site_2_ops)
                if len(shared_ops) > 0:
                    symmetry_related.append((site_1, site_2, shared_ops))

        new_exchanges = []

        for site_1, site_2, operations in symmetry_related:

            # Generate new exchange
            for operation in operations:

                # Get the transformed matrix
                op = operation.point_operation_in_cartesian(unit_cell)
                new_matrix = op @ self._exchange_matrix @ op.T

                # Try to get the transformed cell offset

                vector = self.lattice_vector
                new_vector = operation.point_operation_matrix @ vector

                new_in_cell_vector = site_2.ijk - site_1.ijk

                expected_cell_offset = new_vector - new_in_cell_vector
                cell_offset = CellOffset.coerce(expected_cell_offset)

                name = self.name + " " + ", ".join([f"({operation.text_form})" for operation in operations])
                new_exchanges.append(Exchange(site_1, site_2,
                                              exchange_matrix=new_matrix,
                                              cell_offset=cell_offset,
                                              name = name,
                                              metadata=self.metadata.copy()))

        # Hacky way of excluding the original, add to the list at the start, then remove first
        #  element after the duplicate removal.
        # We also want to include self instead of any copy
        new_exchanges = [self] + new_exchanges

        # Now we want to remove copies of the same exchanges
        for i in range(len(new_exchanges)): # Basically a while loop, but we've sure it is finite
            if i >= len(new_exchanges):
                break
            to_keep: Exchange = new_exchanges[i]
            to_remove: list[int] = []
            for j, to_check in enumerate(new_exchanges[i+1:]):
                # is this exchange related to the check exchange by a translation,
                #  1) if the sites are in the same order, this can only mean they're identical,
                #  2) if the sites are swapped, it means the vector between them is reversed

                # (1)
                if to_keep.site_1 == to_check.site_1 and to_keep.site_2 == to_check.site_2 and \
                    to_keep.cell_offset == to_check.cell_offset:

                    # print("removing", to_check, "as same as", to_keep)

                    to_remove.append(j + i + 1)


                # (2)
                if to_keep.site_1 == to_check.site_2 and to_keep.site_2 == to_check.site_1 and \
                    np.allclose(to_keep.lattice_vector, -to_check.lattice_vector, atol=tolerances.SAME_SITE_ABS_TOL):

                    # print("removing", to_check, "as reversed version of ", to_keep)

                    to_remove.append(j + i + 1)

            # Remove the ones we need to remove, as its ordered we can do
            to_remove = list(set(to_remove))
            to_remove.reverse() # in place reverse
            for j in to_remove:
                del new_exchanges[j]

        # Remove the original input exchange if not included, it will always still be at the front
        if not include_original:
            new_exchanges = new_exchanges[1:]

        return [specialise_exchange(exchange, rounding_exponent=specialisation_rounding_exponent)
                for exchange in new_exchanges]

    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Convert this to a specialised exchange type.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        Exchange or None
            Specialised exchange instance if compatible with this class, or ``None``
            otherwise.
        """
        return exchange

    @property
    def parameter_string(self) -> str:
        """String representation of the exchange parameters."""
        # Note that we reference the _parameter value, not the property that references it
        substrings = []
        for parameter in self.parameters:
            value=self.__dict__["_" + parameter]
            substrings.append(f"{parameter}={value:.5g}")

        return ", ".join(substrings)

    def __repr__(self):

        direction_string = "<->" if self.is_symmetric() else "->"

        return "".join([
            self.__class__.__name__,
            f"('{self.name}', {self.site_1.name} {direction_string} {self.site_2.name}, offset={self.cell_offset}, ",
            self.parameter_string,
            ")"])




class HeisenbergExchange(Exchange):
    r"""Represent a Heisenberg exchange term.

    The exchange takes the form

    .. math::

        H_{ij} = J_{ij} \, (\mathbf{S}_i \cdot \mathbf{S}_j).

    Parameters
    ----------
    site_1 : Site
        Lattice site associated with :math:`\mathbf{S}_i`.
    site_2 : Site
        Lattice site associated with :math:`\mathbf{S}_j`.
    j : float
        Exchange coefficient, :math:`J_{ij}`.
    cell_offset : CellOffsetCoercible, optional
        Offset between the unit cells containing the two sites.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of float, optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.
    """

    exchange_type = "Heisenberg"
    parameters = ["j"]
    parameter_defaults = [1.0]
    short_string = "J"


    def __init__(self, site_1: Site, site_2: Site,
                 j: float,
                 cell_offset: CellOffsetCoercible = None,
                 name: str="",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):

        self._j = j
        self._exchange_matrix = j * np.eye(3)

        super().__init__(site_1=site_1,
                         site_2=site_2,
                         cell_offset=cell_offset,
                         exchange_matrix=self._exchange_matrix,
                         name=name,
                         color=color,
                         metadata=metadata)

    @property
    def j(self):
        """Exchange constant."""
        return self._j

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        json = self._base_serialisation(context)
        json["j"] = self._j
        return json

    @staticmethod
    @expects_keys("j")
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        base = Exchange._base_deserialisation(data, context)

        return HeisenbergExchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            j = data["j"],
            metadata=base.metadata
        )

    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        A Heisenberg exchange is always symmetric, so this always returns ``True``.

        Returns
        -------
        bool
            Always ``True``.
        """
        return True

    def updated(self,
                site_1 : Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                j: float | None = None,
                metadata: ExchangeMetadata | None = None
                ):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        j : float, optional
            Replacement exchange coefficient. If omitted, the current coefficient is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        HeisenbergExchange
            New ``HeisenbergExchange`` instance with the specified fields updated.
        """
        return HeisenbergExchange(
                site_1=self.site_1 if site_1 is None else site_1,
                site_2 = self.site_2 if site_2 is None else site_2,
                cell_offset = self.cell_offset if cell_offset is None else cell_offset,
                name = self.name if name is None else name,
                j = self.j if j is None else j,
                metadata=self.metadata.copy() if metadata is None else metadata.copy()
                )


    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Create a specialised version of this exchange.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        HeisenbergExchange or None
            ``HeisenbergExchange`` instance if ``exchange`` has an isotropic diagonal
            matrix, or ``None`` otherwise.
        """
        m = exchange.exchange_matrix
        if is_diagonal(m) and m[0,0] == m[1,1] and m[1,1] == m[2,2]:
            return HeisenbergExchange(
                site_1=exchange.site_1,
                site_2=exchange.site_2,
                cell_offset=exchange.cell_offset,
                j=float(m[0,0]),
                name=exchange.name,
                metadata=exchange.metadata.copy())
        else:
            return None




class DiagonalExchange(Exchange):
    r"""Represent a diagonal exchange term.

    The exchange takes the form

    .. math::

        H_{ij} = J^{xx}_{ij} \mathbf{S}^x_i \mathbf{S}^x_j + J^{yy}_{ij} \mathbf{S}^y_i \mathbf{S}^y_j
                 + J^{zz}_{ij} \mathbf{S}^z_i \mathbf{S}^z_j.

    Parameters
    ----------
    site_1 : Site
        Lattice site associated with :math:`\mathbf{S}_i`.
    site_2 : Site
        Lattice site associated with :math:`\mathbf{S}_j`.
    j_x : float
        Scalar exchange coefficient for the x component, :math:`J^{xx}_{ij}`.
    j_y : float
        Scalar exchange coefficient for the y component, :math:`J^{yy}_{ij}`.
    j_z : float
        Scalar exchange coefficient for the z component, :math:`J^{zz}_{ij}`.
    cell_offset : CellOffsetCoercible, optional
        Offset between the unit cells containing the two sites.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of float, optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.
    """

    exchange_type = "Diagonal"
    parameters = ["j_x", "j_y", "j_z"]
    parameter_defaults = [1.0, 1.0, 1.0]
    short_string = "J"

    def __init__(self, site_1: Site, site_2: Site,
                 j_x: float, j_y: float, j_z: float,
                 cell_offset: CellOffsetCoercible = None,
                 name: str="",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):

        self._j_x = j_x
        self._j_y = j_y
        self._j_z = j_z

        self._exchange_matrix = np.diag([j_x, j_y, j_z])

        super().__init__(site_1=site_1,
                         site_2=site_2,
                         cell_offset=cell_offset,
                         exchange_matrix=self._exchange_matrix,
                         name=name,
                         color=color,
                         metadata=metadata)

    @property
    def j_x(self):
        """Exchange constant for x."""
        return self._j_x


    @property
    def j_y(self):
        """Exchange constant for y."""
        return self._j_y


    @property
    def j_z(self):
        """Exchange constant for z."""
        return self._j_z

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        json = self._base_serialisation(context)
        json["j_x"] = self._j_x
        json["j_y"] = self._j_y
        json["j_z"] = self._j_z
        return json

    @staticmethod
    @expects_keys("j_x, j_y, j_z")
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        base = Exchange._base_deserialisation(data, context)

        return DiagonalExchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            j_x = data["j_x"],
            j_y = data["j_y"],
            j_z = data["j_z"],
            metadata=base.metadata)

    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        A diagonal exchange is always symmetric, so this always returns ``True``.

        Returns
        -------
        bool
            Always ``True``.
        """
        return True

    def updated(self,
                site_1 : Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                j_x: float | None = None,
                j_y: float | None = None,
                j_z: float | None = None,
                metadata: ExchangeMetadata | None = None,
                ):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        j_x : float, optional
            Replacement x exchange coefficient. If omitted, the current coefficient is reused.
        j_y : float, optional
            Replacement y exchange coefficient. If omitted, the current coefficient is reused.
        j_z : float, optional
            Replacement z exchange coefficient. If omitted, the current coefficient is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        DiagonalExchange
            New ``DiagonalExchange`` instance with the specified fields updated.
        """
        return DiagonalExchange(
                site_1=self.site_1 if site_1 is None else site_1,
                site_2 = self.site_2 if site_2 is None else site_2,
                cell_offset = self.cell_offset if cell_offset is None else cell_offset,
                name = self.name if name is None else name,
                j_x = self.j_x if j_x is None else j_x,
                j_y = self.j_y if j_y is None else j_y,
                j_z = self.j_z if j_z is None else j_z,
                metadata=self.metadata.copy() if metadata is None else metadata.copy())


    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Create a specialised version of this exchange.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        DiagonalExchange or None
            ``DiagonalExchange`` instance if ``exchange`` has a diagonal matrix,
            or ``None`` otherwise.
        """
        m = exchange.exchange_matrix
        if is_diagonal(m):
            return DiagonalExchange(
                site_1=exchange.site_1,
                site_2=exchange.site_2,
                cell_offset=exchange.cell_offset,
                j_x=float(m[0,0]),
                j_y=float(m[1,1]),
                j_z=float(m[2,2]),
                name=exchange.name,
                metadata=exchange.metadata.copy())
        else:
            return None

class XYExchange(Exchange):
    r"""Represent an XY exchange term.

    The exchange takes the form

    .. math::

        H_{ij} = J_{ij} \, (\mathbf{S}^x_i \mathbf{S}^x_j + \mathbf{S}^y_i \mathbf{S}^y_j).

    Parameters
    ----------
    site_1 : Site
        Lattice site associated with :math:`\mathbf{S}_i`.
    site_2 : Site
        Lattice site associated with :math:`\mathbf{S}_j`.
    j : float
        Exchange coefficient for the x and y components, :math:`J_{ij}`.
    cell_offset : CellOffsetCoercible, optional
        Offset between the unit cells containing the two sites.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of float, optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.
    """

    exchange_type = "XY"
    parameters = ["j"]
    parameter_defaults = [1.0]
    short_string = "J"


    @property
    def j(self):
        """Exchange constant for x and y."""
        return self._j

    def __init__(self, site_1: Site, site_2: Site,
                 j: float,
                 cell_offset: CellOffsetCoercible = None,
                 name: str="",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):

        self._j = j
        self._exchange_matrix = np.diag(np.array([j, j, 0.0], dtype=float))

        super().__init__(site_1=site_1,
                         site_2=site_2,
                         cell_offset=cell_offset,
                         exchange_matrix=self._exchange_matrix,
                         name=name,
                         color=color,
                         metadata=metadata)

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        json = self._base_serialisation(context)
        json["j"] = self._j
        return json

    @staticmethod
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        base = Exchange._base_deserialisation(data, context)

        return XYExchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            j = data["j"],
            metadata=base.metadata)

    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        An XY exchange is always symmetric, so this always returns ``True``.

        Returns
        -------
        bool
            Always ``True``.
        """
        return True

    def updated(self,
                site_1: Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                j: float | None = None,
                metadata: ExchangeMetadata | None = None):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        j : float, optional
            Replacement exchange coefficient. If omitted, the current coefficient is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        XYExchange
            New ``XYExchange`` instance with the specified fields updated.
        """
        return XYExchange(
                site_1=self.site_1 if site_1 is None else site_1,
                site_2=self.site_2 if site_2 is None else site_2,
                cell_offset=self.cell_offset if cell_offset is None else cell_offset,
                name=self.name if name is None else name,
                j=self.j if j is None else j,
                metadata=self.metadata.copy() if metadata is None else metadata.copy())


    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Create a specialised version of this exchange.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        XYExchange or None
            ``XYExchange`` instance if ``exchange`` has an XY diagonal matrix,
            or ``None`` otherwise.
        """
        m = exchange.exchange_matrix
        if is_diagonal(m) and m[0,0] == m[1,1] and m[2,2] == 0:
            return XYExchange(
                site_1=exchange.site_1,
                site_2=exchange.site_2,
                cell_offset=exchange.cell_offset,
                j=float(m[0,0]),
                name=exchange.name,
                metadata=exchange.metadata.copy())
        else:
            return None

class XXZExchange(Exchange):
    r"""Represent an XXZ exchange term.

    The exchange takes the form

    .. math::

        H_{ij} = J_{xy} \, (\mathbf{S}^x_i \mathbf{S}^x_j
        + \mathbf{S}^y_i \mathbf{S}^y_j) + J_z \, (\mathbf{S}^z_i \mathbf{S}^z_j).

    Parameters
    ----------
    site_1 : Site
        Lattice site associated with :math:`\mathbf{S}_i`.
    site_2 : Site
        Lattice site associated with :math:`\mathbf{S}_j`.
    j_xy : float
        Exchange coefficient for the x and y components, :math:`J_{xy}`.
    j_z : float
        Exchange coefficient for the z component, :math:`J_z`.
    cell_offset : CellOffsetCoercible, optional
        Offset between the unit cells containing the two sites.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of float, optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.
    """

    exchange_type = "XXZ"
    parameters = ["j_xy", "j_z"]
    parameter_defaults = [1.0, 1.0]
    short_string = "J"

    def __init__(self, site_1: Site, site_2: Site,
                 j_xy: float, j_z: float,
                 cell_offset: CellOffsetCoercible = None,
                 name: str="",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):

        self._j_xy = j_xy
        self._j_z = j_z

        self._exchange_matrix = np.diag([j_xy, j_xy, j_z])

        super().__init__(site_1=site_1,
                         site_2=site_2,
                         cell_offset=cell_offset,
                         exchange_matrix=self._exchange_matrix,
                         name=name,
                         color=color,
                         metadata=metadata)



    @property
    def j_xy(self):
        """Exchange constant for x and y."""
        return self._j_xy


    @property
    def j_z(self):
        """Exchange constant for z."""
        return self._j_z

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        json = self._base_serialisation(context)
        json["j_xy"] = self._j_xy
        json["j_z"] = self._j_z
        return json

    @staticmethod
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        base = Exchange._base_deserialisation(data, context)

        return XXZExchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            j_xy = data["j_xy"],
            j_z = data["j_z"],
            metadata=base.metadata)


    def updated(self,
                site_1: Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                j_xy: float | None = None,
                j_z: float | None = None,
                metadata: ExchangeMetadata | None = None
                ):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        j_xy : float, optional
            Replacement x-y exchange coefficient. If omitted, the current coefficient is reused.
        j_z : float, optional
            Replacement z exchange coefficient. If omitted, the current coefficient is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        XXZExchange
            New ``XXZExchange`` instance with the specified fields updated.
        """
        return XXZExchange(
                site_1=self.site_1 if site_1 is None else site_1,
                site_2=self.site_2 if site_2 is None else site_2,
                cell_offset=self.cell_offset if cell_offset is None else cell_offset,
                name=self.name if name is None else name,
                j_xy=self.j_xy if j_xy is None else j_xy,
                j_z=self.j_z if j_z is None else j_z,
                metadata=self.metadata.copy() if metadata is None else metadata.copy())
    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        An XXZ exchange is always symmetric, so this always returns ``True``.

        Returns
        -------
        bool
            Always ``True``.
        """
        return True

    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Create a specialised version of this exchange.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        XXZExchange or None
            ``XXZExchange`` instance if ``exchange`` has an XXZ diagonal matrix,
            or ``None`` otherwise.
        """
        m = exchange.exchange_matrix
        if is_diagonal(m) and m[0,0] == m[1,1]:
            return XXZExchange(
                site_1=exchange.site_1,
                site_2=exchange.site_2,
                cell_offset=exchange.cell_offset,
                j_xy=float(m[0,0]),
                j_z=float(m[2,2]),
                name=exchange.name,
                metadata=exchange.metadata.copy())
        else:
            return None

class IsingExchange(Exchange):
    r"""Represent an Ising exchange term for the z component.

    The exchange takes the form

    .. math::

        H_{ij} = J_{ij} \, \mathbf{S}^z_i \mathbf{S}^z_j.

    Parameters
    ----------
    site_1 : Site
        Lattice site associated with :math:`\mathbf{S}_i`.
    site_2 : Site
        Lattice site associated with :math:`\mathbf{S}_j`.
    j_z : float
        Exchange coefficient for the z component, :math:`J_{ij}`.
    cell_offset : CellOffsetCoercible, optional
        Offset between the unit cells containing the two sites.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of float, optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.
    """

    exchange_type = "Ising"
    parameters = ["j_z"]
    parameter_defaults = [1.0]
    short_string = "J"

    def __init__(self, site_1: Site, site_2: Site,
                 j_z: float,
                 cell_offset: CellOffsetCoercible = None,
                 name: str="",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):
        self._j_z = j_z

        self._exchange_matrix = np.diag([0.0, 0.0, j_z])

        super().__init__(site_1=site_1,
                         site_2=site_2,
                         cell_offset=cell_offset,
                         exchange_matrix=self._exchange_matrix,
                         name=name,
                         color=color,
                         metadata=metadata)

    @property
    def j_z(self):
        """Exchange constant for z."""
        return self._j_z

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        json = self._base_serialisation(context)
        json["j_z"] = self._j_z
        return json

    @staticmethod
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        base = Exchange._base_deserialisation(data, context)

        return IsingExchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            j_z = data["j_z"],
            metadata=base.metadata)


    def updated(self,
                site_1: Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                j_z: float | None = None,
                metadata: ExchangeMetadata | None = None):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        j_z : float, optional
            Replacement z exchange coefficient. If omitted, the current coefficient is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        IsingExchange
            New ``IsingExchange`` instance with the specified fields updated.
        """
        return IsingExchange(
                site_1=self.site_1 if site_1 is None else site_1,
                site_2=self.site_2 if site_2 is None else site_2,
                cell_offset=self.cell_offset if cell_offset is None else cell_offset,
                name=self.name if name is None else name,
                j_z=self.j_z if j_z is None else j_z,
                metadata=self.metadata.copy() if metadata is None else metadata.copy())

    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        An Ising exchange is always symmetric, so this always returns ``True``.

        Returns
        -------
        bool
            Always ``True``.
        """
        return True

    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Create a specialised version of this exchange.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        IsingExchange or None
            ``IsingExchange`` instance if ``exchange`` has an Ising (z-only) diagonal
            matrix, or ``None`` otherwise.
        """
        m = exchange.exchange_matrix
        if is_diagonal(m) and m[0, 0] == 0 and m[1, 1] == 0:
            return IsingExchange(
                site_1=exchange.site_1,
                site_2=exchange.site_2,
                cell_offset=exchange.cell_offset,
                j_z=float(m[2, 2]),
                name=exchange.name,
                metadata=exchange.metadata.copy())
        else:
            return None

class DMExchange(Exchange):
    r"""Represent a Dzyaloshinskii-Moriya exchange term.

    The exchange takes the form

    .. math::

        H_{ij} = \mathbf{D}_{ij} \cdot (\mathbf{S}_i \times \mathbf{S}_j).

    Parameters
    ----------
    site_1 : Site
        Lattice site associated with :math:`\mathbf{S}_i`.
    site_2 : Site
        Lattice site associated with :math:`\mathbf{S}_j`.
    d_x : float
        x component of the D vector, :math:`\mathbf{D}^x_{ij}`.
    d_y : float
        y component of the D vector, :math:`\mathbf{D}^y_{ij}`.
    d_z : float
        z component of the D vector, :math:`\mathbf{D}^z_{ij}`.
    cell_offset : CellOffsetCoercible, optional
        Offset between the unit cells containing the two sites.
    name : str, optional
        Name for the exchange term. Default is ``""``.
    color : tuple of float, optional
        RGB color used when displaying the exchange term.
    metadata : ExchangeMetadata, optional
        Metadata attached to the exchange term.
    """

    exchange_type = "Dzyaloshinskii-Moriya"
    parameters = ["d_x", "d_y", "d_z"]
    parameter_defaults = [1.0, 1.0, 1.0]
    short_string = "DM"


    def __init__(self, site_1: Site, site_2: Site,
                 d_x: float, d_y: float, d_z: float,
                 cell_offset: CellOffsetCoercible = None,
                 name: str="",
                 color: tuple[float, float, float] | None = None,
                 metadata: ExchangeMetadata | None = None):

        self._d_x = d_x
        self._d_y = d_y
        self._d_z = d_z

        self._exchange_matrix = triple_product_matrix(np.array([d_x, d_y, d_z], dtype=float))

        super().__init__(site_1=site_1,
                         site_2=site_2,
                         cell_offset=cell_offset,
                         exchange_matrix=self._exchange_matrix,
                         name=name,
                         color=color,
                         metadata=metadata)


    @property
    def d_x(self):
        """DM exchange constant for x."""
        return self._d_x

    @property
    def d_y(self):
        """DM exchange constant for y."""
        return self._d_y

    @property
    def d_z(self):
        """DM exchange constant for z."""
        return self._d_z

    def _exchange_serialise(self, context: SPWSerialisationContext) -> dict:
        json = self._base_serialisation(context)
        json["d_x"] = self._d_x
        json["d_y"] = self._d_y
        json["d_z"] = self._d_z
        return json

    @staticmethod
    def _exchange_deserialise(data: dict, context: SPWSerialisationContext):
        base = Exchange._base_deserialisation(data, context)

        return DMExchange(
            site_1=base.site_1,
            site_2=base.site_2,
            cell_offset=base.cell_offset,
            name=base.name,
            d_x = data["d_x"],
            d_y = data["d_y"],
            d_z = data["d_z"],
            metadata=base.metadata)


    def updated(self,
                site_1: Site | None = None,
                site_2: Site | None = None,
                cell_offset: CellOffset | None = None,
                name: str | None = None,
                d_x: float | None = None,
                d_y: float | None = None,
                d_z: float | None = None,
                metadata: ExchangeMetadata | None = None):
        """Return a copy of this exchange with variables replaced.

        Parameters
        ----------
        site_1 : Site, optional
            Replacement first lattice site. If omitted, the current site is reused.
        site_2 : Site, optional
            Replacement second lattice site. If omitted, the current site is reused.
        cell_offset : CellOffset, optional
            Replacement unit-cell offset. If omitted, the current offset is reused.
        name : str, optional
            Replacement exchange name. If omitted, the current name is reused.
        d_x : float, optional
            Replacement x D-vector component. If omitted, the current component is reused.
        d_y : float, optional
            Replacement y D-vector component. If omitted, the current component is reused.
        d_z : float, optional
            Replacement z D-vector component. If omitted, the current component is reused.
        metadata : ExchangeMetadata, optional
            Replacement metadata. If omitted, the current metadata is copied.

        Returns
        -------
        DMExchange
            New ``DMExchange`` instance with the specified fields updated.
        """
        return DMExchange(
                site_1=self.site_1 if site_1 is None else site_1,
                site_2=self.site_2 if site_2 is None else site_2,
                cell_offset=self.cell_offset if cell_offset is None else cell_offset,
                name=self.name if name is not None else name,
                d_x=self.d_x if d_x is None else d_x,
                d_y=self.d_y if d_y is None else d_y,
                d_z=self.d_z if d_z is None else d_z,
                metadata=self.metadata.copy() if metadata is None else metadata.copy())


    def is_symmetric(self):
        """Return whether this is a symmetric exchange.

        Returns
        -------
        bool
            ``True`` if all D-vector components are zero, ``False`` otherwise.
        """
        return self.d_x == 0 and self.d_y == 0 and self.d_z == 0

    @staticmethod
    def _specialise(exchange: "Exchange") -> Optional["Exchange"]:
        """Create a specialised version of this exchange.

        Parameters
        ----------
        exchange : Exchange
            Exchange instance to specialise.

        Returns
        -------
        DMExchange or None
            ``DMExchange`` instance if ``exchange`` has an antisymmetric matrix,
            or ``None`` otherwise.
        """
        m = exchange.exchange_matrix

        if not np.all(np.diagonal(m) == 0):
            return None

        if m[0,1] != -m[1,0] or m[0,2] != -m[2,0] or m[1,2] != -m[2,1]:
            return None

        z = float(m[0,1])
        y = -float(m[0,2])
        x = float(m[1,2])

        return DMExchange(
                site_1=exchange.site_1,
                site_2=exchange.site_2,
                cell_offset=exchange.cell_offset,
                d_x=x,
                d_y=y,
                d_z=z,
                name=exchange.name,
                metadata=exchange.metadata.copy())


all_exchanges = [HeisenbergExchange, DiagonalExchange, XXZExchange, XYExchange, IsingExchange, DMExchange]
exchanges_lookup = {exchange.exchange_type: exchange for exchange in all_exchanges}
lowercase_exchange_lookup = {exchange.exchange_type.lower(): exchange for exchange in all_exchanges}

_specialisation_search = [HeisenbergExchange, XYExchange,  XXZExchange, IsingExchange, DiagonalExchange, DMExchange]

def specialise_exchange(exchange: Exchange, rounding_exponent: int | None = None):
    """Find the narrowest exchange subclass to fit the exchange.

    Parameters
    ----------
    exchange : Exchange
        Exchange term to specialise.
    rounding_exponent : int, optional
        Number of decimal places to round the exchange matrix to when testing for
        specialised forms, or ``None`` to disable rounding. Default is ``None``.

    Returns
    -------
    Exchange
        Specialised ``Exchange`` subclass instance, or the original/general
        ``Exchange`` if no narrower subclass matches.

    Notes
    -----
    To handle numerical inaccuracies when ``rounding_exponent`` is provided, both
    the unrounded and rounded exchange matrices are tested against candidate
    subclasses. If both specialise to the same class, the unrounded specialised
    exchange is returned; otherwise, the rounded specialised exchange is returned.
    """
    unrounded_specialised = exchange


    for Ex in _specialisation_search:
        specialised = Ex._specialise(exchange)
        if specialised is not None:
            unrounded_specialised = specialised
            break

    # Return case for no rounding
    if rounding_exponent is None:
        return unrounded_specialised

    # Get the rounded version
    rounded_exchange = exchange.generalise().updated(
        exchange_matrix=np.round(exchange.exchange_matrix, decimals=rounding_exponent))

    rounded_specialised = rounded_exchange

    for Ex in _specialisation_search:
        specialised = Ex._specialise(rounded_exchange)
        if specialised is not None:
            rounded_specialised = specialised
            break

    # Return the unrounded one if the classes are the same, otherwise, return the rounded one
    if rounded_specialised.__class__ == unrounded_specialised.__class__:
        return unrounded_specialised
    else:
        return rounded_specialised
