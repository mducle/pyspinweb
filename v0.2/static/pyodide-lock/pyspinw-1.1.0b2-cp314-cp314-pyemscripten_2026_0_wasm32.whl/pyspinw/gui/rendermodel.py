"""Representation of the Hamiltonian that has lots of precalculated stuff needed for rendering it."""
import warnings
from collections import defaultdict
from fractions import Fraction

import numpy as np

from pyspinw.anisotropy import Anisotropy
from pyspinw.cell_offsets import cell_offset_generator
from pyspinw.exchange import Exchange
from pyspinw.gui.edge_cases import add_extra_edge_lines, add_extra_edge_points
from pyspinw.gui.wrap_line import split_and_wrap_line_segment
from pyspinw.hamiltonian import Hamiltonian
from pyspinw.site import Site
from pyspinw.symmetry.supercell import CommensurateSupercell, RotationSupercell, PropagationVector
from pyspinw.symmetry.unitcell import UnitCell
from pyspinw.util import rotation_from_z


class Component:
    """Base class for components.

    Parameters
    ----------
    model_matrix : (4, 4) numpy.ndarray
        4x4 model transformation matrix.
    """

    def __init__(self, model_matrix: np.ndarray):
        self.model_matrix = model_matrix

class Selectable(Component):
    """Components that can be selected in the viewer.

    Parameters
    ----------
    render_id : int
        Unique integer identifier used for selection rendering.
    model_matrix : (4, 4) numpy.ndarray
        4x4 model transformation matrix.
    """

    def __init__(self, render_id: int, model_matrix: np.ndarray):
        super().__init__(model_matrix)

        self.render_id = render_id


class RenderSite(Selectable):
    """Render information for each site.

    Parameters
    ----------
    render_id : int
        Unique integer identifier used for selection rendering.
    site : Site
        Magnetic or atomic site to render.
    unit_cell : UnitCell
        Unit cell used for coordinate conversion.
    offset : tuple of (int, int, int) or None
        Cell offset of the site in the supercell expansion.
    """

    @staticmethod
    def site_model_matrix(position, spin, unit_cell):
        """Model matrix for a site.

        Parameters
        ----------
        position : array_like
            Fractional coordinates of the site.
        spin : array_like
            Spin vector of the site.
        unit_cell : UnitCell
            Unit cell used to convert fractional coordinates to Cartesian.

        Returns
        -------
        (4, 4) numpy.ndarray
            4x4 ``float32`` model transformation matrix.
        """
        rotation = rotation_from_z(spin)
        translation = unit_cell.lattice_units_to_cartesian(position)

        model_matrix = np.zeros((4, 4), dtype=np.float32)
        model_matrix[3,3] = 1.0
        model_matrix[:3, :3] = rotation
        model_matrix[:3, 3] = translation

        return model_matrix

    def __init__(self, render_id: int, site: Site, unit_cell: UnitCell, offset: tuple[int, int, int] | None):
        # Build model matrix

        position, spin = site.ijk, site.base_spin
        model_matrix = self.site_model_matrix(position, spin, unit_cell)

        super().__init__(render_id, model_matrix)
        self.site = site
        self.offset = offset
        self.color = site.metadata.color
        self.radius = 1.0 if site.metadata.radius is None else site.metadata.radius

        self.pretty_render_model_matrices = [self.site_model_matrix(new_position, spin, unit_cell)
                                             for new_position in add_extra_edge_points(position)]

        self.is_magnetic = np.sum(spin**2) > 1e-12


    def model_matrices(self, pretty: bool) -> list[np.ndarray]:
        """Get list of model matrices, pretty flag control whether to include duplicates for cell boundaries.

        Parameters
        ----------
        pretty : bool
            Whether to include periodic boundary duplicate matrices.

        Returns
        -------
        list of (4, 4) numpy.ndarray
            List of 4x4 model transformation matrices.
        """
        if pretty:
            return self.pretty_render_model_matrices
        else:
            return [self.model_matrix]


class RenderExchange(Selectable):
    """Render information for each exchange.

    Parameters
    ----------
    render_id : int
        Unique integer identifier used for selection rendering.
    exchange : Exchange
        Exchange interaction to render.
    unit_cell : UnitCell
        Unit cell used for coordinate conversion.
    """

    @staticmethod
    def segment_model_matrix(a, b, unit_cell):
        """Model matrix for a line segment.

        Parameters
        ----------
        a : array_like
            Start point of the segment in fractional coordinates.
        b : array_like
            End point of the segment in fractional coordinates.
        unit_cell : UnitCell
            Unit cell used to convert fractional coordinates to Cartesian.

        Returns
        -------
        (4, 4) numpy.ndarray
            4x4 ``float32`` model transformation matrix.
        """
        # The model this is designed for is a tube that goes from (0,0,0) to (0,0,1)

        translation = unit_cell.lattice_units_to_cartesian(a)
        delta = unit_cell.lattice_units_to_cartesian(b) - translation

        length = np.sqrt(np.sum(delta**2))

        rotation = rotation_from_z(delta)

        model_matrix = np.zeros((4, 4), dtype=np.float32)
        model_matrix[3,3] = 1.0
        model_matrix[:3, :3] = (rotation @ np.diag([1,1,length]) )
        model_matrix[:3, 3] = translation

        return model_matrix

    def __init__(self, render_id: int, exchange: Exchange, unit_cell: UnitCell):

        self.exchange = exchange
        self.color = exchange.metadata.color

        # self.color = (1.0, 0.4, 0.8) if exchange.metadata.color is None else exchange.metadata.color

        p1 = exchange.site_1.ijk
        p2 = exchange.site_2.ijk + exchange.cell_offset.vector

        model_matrix = self.segment_model_matrix(p1, p2, unit_cell)

        super().__init__(render_id, model_matrix)

        # Create prettified model matrices
        _, sections = split_and_wrap_line_segment(p1, p2)
        sections = add_extra_edge_lines(sections)
        self.split_model_matrices = [self.segment_model_matrix(s1, s2, unit_cell) for s1, s2 in sections]

    def model_matrices(self, pretty: bool) -> list[np.ndarray]:
        """Either the default matrix in a list, or a list of the prettified matrices.

        Parameters
        ----------
        pretty : bool
            Whether to return wrapped and boundary-duplicated segment matrices.

        Returns
        -------
        list of (4, 4) numpy.ndarray
            List of 4x4 model transformation matrices.
        """
        if pretty:
            return self.split_model_matrices
        else:
            return [self.model_matrix]


class RenderAnisotropy(Component):
    """Render information for anisotropies.

    Parameters
    ----------
    anisotropy : Anisotropy
        Single-ion anisotropy term to render.
    unit_cell : UnitCell
        Unit cell used for coordinate conversion.
    scale : float
        Global eigenvalue range scaling factor.
    """

    # Don't subclass selectable as we don't want to select anisotropies from the viewer

    _epsilon = 0.02

    @staticmethod
    def calculate_model_matrix(position,
                               anisotropy: Anisotropy,
                               unit_cell: UnitCell,
                               scale: float):
        """Gets the model matrix for the anisotropy (see dev docs 'anisotropy_representions').

        Parameters
        ----------
        position : array_like
            Fractional coordinates of the site.
        anisotropy : Anisotropy
            Single-ion anisotropy term.
        unit_cell : UnitCell
            Unit cell used to convert fractional coordinates to Cartesian.
        scale : float
            Global eigenvalue range scaling factor.

        Returns
        -------
        (4, 4) numpy.ndarray
            4x4 ``float32`` model transformation matrix.
        """
        symmetrised = -0.5 * (anisotropy.anisotropy_matrix + anisotropy.anisotropy_matrix.T)

        min_eig = np.min(np.linalg.eigvals(symmetrised))

        ellipsoid = (RenderAnisotropy._epsilon * np.eye(3)) - (min_eig * np.eye(3) - symmetrised)/scale

        # Turn the quadratic coefficients into a transformation
        translation = unit_cell.lattice_units_to_cartesian(position)
        rotation = np.linalg.cholesky(ellipsoid)

        model_matrix = np.zeros((4, 4), dtype=np.float32)
        model_matrix[3,3] = 1.0
        model_matrix[:3, :3] = rotation
        model_matrix[:3, 3] = translation

        return model_matrix


    def __init__(self, anisotropy: Anisotropy, unit_cell: UnitCell, scale: float):


        super().__init__(np.eye(4))
        self.anisotropy = anisotropy
        self.site = anisotropy.site
        self.xyz = unit_cell.lattice_units_to_cartesian(anisotropy.site.ijk)

        self.pretty_render_model_matrices = [self.calculate_model_matrix(
                                                new_position, anisotropy, unit_cell, scale)
                                                for new_position in add_extra_edge_points(anisotropy.site.ijk)]

        # Matrix to convert
        self.model_matrix = self.calculate_model_matrix(
            anisotropy.site.ijk, anisotropy, unit_cell, scale)


    def model_matrices(self, pretty: bool) -> list[np.ndarray]:
        """Get list of model matrices, pretty flag control whether to include duplicates for cell boundaries.

        Parameters
        ----------
        pretty : bool
            Whether to include periodic boundary duplicate matrices.

        Returns
        -------
        list of (4, 4) numpy.ndarray
            List of 4x4 model transformation matrices.
        """
        if pretty:
            return self.pretty_render_model_matrices
        else:
            return [self.model_matrix]

class RenderModel:
    """Model of the hamiltonian, contains lots of derived information for rendering and text representation.

    Parameters
    ----------
    hamiltonian : Hamiltonian
        Hamiltonian to build the render model from.
    copies : tuple of (int, int, int), optional
        Additional supercell scaling along each lattice vector. Default is
        ``(1, 1, 1)``.
    rotation_supercell_expansion_max : tuple of (int, int, int), optional
        Maximum denominator along each axis when approximating a
        ``RotationSupercell`` propagation vector as a commensurate cell.
        Default is ``(10, 10, 10)``.
    propagation_vector_tolerance : float, optional
        Tolerance for matching a propagation vector component to a rational
        fraction. Default is ``1e-4``.

    Raises
    ------
    TypeError
        If the Hamiltonian supercell is neither a ``RotationSupercell`` nor a
        ``CommensurateSupercell``.
    """

    def __init__(self,
                 hamiltonian: Hamiltonian,
                 copies: tuple[int, int, int] = (1,1,1),
                 rotation_supercell_expansion_max=(10,10,10),
                 propagation_vector_tolerance=1e-4):


        # Deal with added scaling, and rotation supercells

        # Change the scaling on the supercell if its commensurate according to `copies`
        if isinstance(hamiltonian.structure.supercell, CommensurateSupercell):

            new_scaling = tuple(x*y for x, y in zip(copies, hamiltonian.structure.supercell.scaling))

            hamiltonian = hamiltonian.updated(
                structure = hamiltonian.structure.updated(
                    supercell = hamiltonian.structure.supercell.rescale(new_scaling)
                ))

            expansion_size = None

        # If it's a rotation supercell, we want to expand it sensibly
        elif isinstance(hamiltonian.structure.supercell, RotationSupercell):
            # Find the periodicity of the supercell, this is a bit weird because of floating points
            # Basic plan is to see if the vector is close to a quotient in some limited set of quotients
            # i.e. Q_test = {a/b | a,b in N, b < n}
            # we can find the closest one of these using Fraction.limit_denominator
            # then, when we have the closest one, see if it is close enough


            propagation_vector = hamiltonian.structure.supercell.propagation_vector.vector

            expansion_size = [s for s in rotation_supercell_expansion_max]
            for i in range(3):
                closest_fraction = Fraction(propagation_vector[i])\
                    .limit_denominator(rotation_supercell_expansion_max[i])

                if abs(float(closest_fraction) - propagation_vector[i]) < propagation_vector_tolerance:
                    expansion_size[i] = closest_fraction.denominator

            expansion_size = tuple(expansion_size)


        else:
            raise TypeError("Expected supercell to be of type RotationSupercell or subclass of CommensurateSupercell")

        self.hamiltonian = hamiltonian

        self.expanded, site_mapping, self.exchange_mapping, self.anisotropy_mapping = \
            self.hamiltonian._expand_with_mapping(expansion_size)

        self.expansion_size = hamiltonian.structure.supercell.cell_size() if expansion_size is None else expansion_size

        self.site_expanded_uid_to_original_uid: dict[int, int] = {}
        self.site_original_uid_to_expanded_uid: defaultdict[int, list[int]] = defaultdict(list)

        self.original_sites = self.hamiltonian.structure.sites

        for (parent_unique_id, offset), child_site in site_mapping.items():
            self.site_original_uid_to_expanded_uid[parent_unique_id].append(child_site.unique_id)
            self.site_expanded_uid_to_original_uid[child_site.unique_id] = parent_unique_id

        self.site_expanded_uid_to_original_index_and_offset = \
            {site.unique_id: data for data, site in site_mapping.items()}

        #
        # Build the data structure for rendering
        #

        render_id = 1

        self.render_map: dict[int, Component] = {}
        self.expanded_site_unique_id_to_render_id: dict[int, int] = {}

        self.original_site_unique_id_to_index: dict[int, int] = {}
        for index, site in enumerate(self.hamiltonian.structure.sites):
            self.original_site_unique_id_to_index[site.unique_id] = index

        self.expanded_index_to_original_index = []

        #
        # Create render data for sites
        #
        self.sites: list[RenderSite] = []
        for site in self.expanded.structure.sites:

            parent_index, offset = self.site_expanded_uid_to_original_index_and_offset[site.unique_id]
            render_site = RenderSite(render_id, site, self.expanded.structure.unit_cell, offset)

            self.sites.append(render_site)
            self.render_map[render_id] = render_site
            self.expanded_site_unique_id_to_render_id[site.unique_id] = render_id

            parent_unique_id = self.site_expanded_uid_to_original_uid[site.unique_id]

            self.expanded_index_to_original_index.append(self.original_site_unique_id_to_index[parent_unique_id])

            render_id += 1

        self.original_index_to_expanded = defaultdict(list)
        for expanded, original in enumerate(self.expanded_index_to_original_index):
            self.original_index_to_expanded[original].append(expanded)

        #
        # Create render data for exchanges
        #

        self.exchanges = []
        for exchange in self.expanded.exchanges:
            render_exchange = RenderExchange(render_id, exchange, self.expanded.structure.unit_cell)
            self.exchanges.append(render_exchange)
            self.render_map[render_id] = render_exchange
            render_id += 1

        self.anisotropies = []

        # We want to calculate the range of eigenvalues that we have, including zero in that
        scale = 0.0
        for anisotropy in self.expanded.anisotropies:
            symmetrized = 0.5*(anisotropy.anisotropy_matrix + anisotropy.anisotropy_matrix.T)
            eigenvalues = np.linalg.eigvals(symmetrized)
            smallest = np.min(eigenvalues)
            largest = np.max(eigenvalues)

            new_scale = largest - smallest

            if scale < new_scale:
                scale = new_scale



        for anisotropy in self.expanded.anisotropies:
            render_anisotropy = RenderAnisotropy(anisotropy, self.expanded.structure.unit_cell, scale)
            self.anisotropies.append(render_anisotropy)
            self.render_map[render_id] = render_anisotropy
            render_id += 1

        #
        # Unit cell axes
        #

        translation_matrix = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,.5],[0,0,0,1]], dtype=np.float32)

        # get orthogonal axes transforms

        unit_cell_orthobasis = hamiltonian.structure.unit_cell._xyz_spins

        self.unit_cell_orthobasis_transforms = []
        for direction in unit_cell_orthobasis:
            rotation_matrix = np.eye(4, dtype=np.float32)
            rotation_matrix[:3, :3] = rotation_from_z(direction)

            self.unit_cell_orthobasis_transforms.append(rotation_matrix @ translation_matrix)

        # get normal xyz

        unit_cell_basis = hamiltonian.structure.unit_cell._xyz

        self.unit_cell_axes_transforms = []
        for direction in unit_cell_basis:
            rotation_matrix = np.eye(4, dtype=np.float32)
            rotation_matrix[:3, :3] = rotation_from_z(direction)

            self.unit_cell_axes_transforms.append(rotation_matrix @ translation_matrix)

    def cells(self):
        """Generator for cell offsets for each of the displayed cells.

        Returns
        -------
        Iterator[CellOffset]
            Generator of ``CellOffset`` instances for the expanded supercell.
        """
        return cell_offset_generator(*self.expansion_size)

