"""Window that shows when settings button is clicked."""

from dataclasses import replace

from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QDialogButtonBox, QColorDialog, QWidget, QGridLayout

from pyspinw.gui.displayoptions import DisplayOptions
from pyspinw.gui.util import QRightLabel, QColorPatch


class SettingsDialog(QDialog):
    """Dialog with settings options.

    Parameters
    ----------
    current_options : DisplayOptions
        Current display options used to initialise the dialog controls.
    parent : QWidget or None, optional
        Parent widget. Default is ``None``.
    """

    def __init__(self, current_options: DisplayOptions, parent=None):
        self._current_options = current_options
        super().__init__(parent=parent)

        self.setWindowTitle("Settings")

        layout = QVBoxLayout(self)

        inner_widget = QWidget(self)
        inner_layout = QGridLayout()
        inner_widget.setLayout(inner_layout)

        self._background = QColorPatch(*current_options.background_color, parent=self)
        inner_layout.addWidget(QRightLabel("Background Color"), 0, 0)
        inner_layout.addWidget(self._background, 0, 1)

        self._sites = QColorPatch(*current_options.default_site_color, parent=self)
        inner_layout.addWidget(QRightLabel("Sites Default Color"), 1, 0)
        inner_layout.addWidget(self._sites, 1, 1)

        self._exchanges = QColorPatch(*current_options.default_exchange_color, parent=self)
        inner_layout.addWidget(QRightLabel("Exchange Default Color"), 2, 0)
        inner_layout.addWidget(self._exchanges, 2, 1)

        self._selected = QColorPatch(*current_options.selected_color, parent=self)
        inner_layout.addWidget(QRightLabel("Selection Color"), 3, 0)
        inner_layout.addWidget(self._selected, 3, 1)

        self._hover = QColorPatch(*current_options.hover_color, parent=self)
        inner_layout.addWidget(QRightLabel("Hover Color"), 4, 0)
        inner_layout.addWidget(self._hover, 4, 1)

        self._selected_hover = QColorPatch(*current_options.selected_hover_color, parent=self)
        inner_layout.addWidget(QRightLabel("Selected Hover Color"), 5, 0)
        inner_layout.addWidget(self._selected_hover, 5, 1)

        # Anisotropy colours

        self._anisotropies = QColorPatch(*current_options.anisotropy_color, parent=self)
        inner_layout.addWidget(QRightLabel("Anisotropies"), 6, 0)
        inner_layout.addWidget(self._anisotropies, 6, 1)

        # Add inner widget
        layout.addWidget(inner_widget)

        # OK / Cancel buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )

        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout.addWidget(buttons)

    def new_display_options(self):
        """Get the updated display options.

        Returns
        -------
        DisplayOptions
            Updated display options incorporating the color selections from the
            dialog.
        """
        return replace(
            self._current_options,
            background_color = self._background.rgb,
            default_exchange_color = self._exchanges.rgb,
            default_site_color = self._sites.rgb,
            selected_color = self._selected.rgb,
            hover_color = self._hover.rgb,
            selected_hover_color = self._selected_hover.rgb,
            anisotropy_color=self._anisotropies.rgb)


if __name__ == "__main__":
    options = DisplayOptions()

    from PySide6.QtWidgets import QApplication

    app = QApplication()
    widget = SettingsDialog(options)

    if widget.exec() == QDialog.Accepted:
        value = widget.new_display_options()
        print(value)
