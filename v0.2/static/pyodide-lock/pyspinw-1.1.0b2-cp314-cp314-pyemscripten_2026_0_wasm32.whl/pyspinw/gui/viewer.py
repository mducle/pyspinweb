"""Viewer window."""
import ctypes
import os
import sys

import numpy as np
from PySide6.QtGui import QSurfaceFormat
from imageio import imwrite

from PySide6.QtCore import Qt, QDir
from PySide6.QtWidgets import QSplitter, QWidget, QVBoxLayout, QApplication, QFileDialog, QMessageBox
from numpy._typing import ArrayLike

from pyspinw import Structure
from pyspinw.gui.crystalview import CrystalViewerWidget
from pyspinw.gui.icons.iconload import png_icon
from pyspinw.gui.rendermodel import RenderModel
from pyspinw.gui.displayoptionstoolbar import DisplayOptionsToolbar
from pyspinw.gui.displayoptions import DisplayOptions
from pyspinw.gui.textdisplay import TextDisplay
from pyspinw.hamiltonian import Hamiltonian
from pyspinw.util import rotation_from_z

# Force desktop OpenGL before any Qt import (critical on macOS)
os.environ.setdefault("QT_OPENGL", "desktop")
os.environ.setdefault("QT_MAC_WANTS_LAYER", "1")


# Request OpenGL 4.1 core profile — must be called before QApplication is created.
# Equivalent to GLFW's glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR/MINOR, 4/1)
# and glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE).
_fmt = QSurfaceFormat()
_fmt.setVersion(4, 1)
_fmt.setProfile(QSurfaceFormat.CoreProfile)
_fmt.setRenderableType(QSurfaceFormat.OpenGL)
_fmt.setSamples(4)
_fmt.setDepthBufferSize(24)
_fmt.setStencilBufferSize(8)
QSurfaceFormat.setDefaultFormat(_fmt)


_unique_id_counter = -1
def _generate_unique_id():
    """Generate a unique ID for each viewer.

    Returns
    -------
    int
        Unique integer identifier.
    """
    global _unique_id_counter # noqa: PLW0603
    _unique_id_counter += 1
    return _unique_id_counter

class Viewer(QWidget):
    """Main viewer class.

    Parameters
    ----------
    hamiltonian : Hamiltonian
        Hamiltonian to display in the viewer.
    initial_rotation : (3, 3) numpy.ndarray or None, optional
        Initial 3x3 view rotation matrix. Default is ``None``.
    initial_distance : float or None, optional
        Initial camera distance from the view origin. Default is ``None``.
    display_options : DisplayOptions or None, optional
        Initial display options. Default is ``None``.
    save_config_on_exit : bool, optional
        Whether to save display configuration when closing the viewer. Default
        is ``True``.
    copies : tuple of (int, int, int), optional
        Supercell scaling along each lattice vector. Default is ``(1, 1, 1)``.
    rotation_supercell_expansion_max : tuple of (int, int, int), optional
        Maximum denominator along each axis when approximating a
        ``RotationSupercell`` propagation vector as a commensurate cell.
        Default is ``(10, 10, 10)``.
    propagation_vector_commensurability_tolerance : float, optional
        Tolerance for matching a propagation vector component to a rational
        fraction. Default is ``1e-4``.
    parent : QWidget or None, optional
        Parent widget. Default is ``None``.

    Raises
    ------
    ValueError
        If ``copies`` or ``rotation_supercell_expansion_max`` is not a triple
        of ints, if ``initial_rotation`` is not a valid rotation matrix, or if
        ``initial_distance`` is not strictly positive.
    """

    def __init__(self,
                 hamiltonian: Hamiltonian,
                 initial_rotation: np.ndarray | None = None,
                 initial_distance: float | None = None,
                 display_options: DisplayOptions | None = None,
                 save_config_on_exit: bool = True,
                 copies: tuple[int, int, int] = (1, 1, 1),
                 rotation_supercell_expansion_max: tuple[int, int, int] = (10, 10, 10),
                 propagation_vector_commensurability_tolerance=1e-4,
                 parent=None):

        super().__init__(parent)

        # Some parameter checking
        if len(copies) != 3 and not all(isinstance(x, int) for x in copies):
            raise ValueError("Expected `copies` to be a triple of ints")

        if len(rotation_supercell_expansion_max) != 3 and \
                not all(isinstance(x, int) for x in rotation_supercell_expansion_max):
            raise ValueError("Expected `rotation_supercell_expansion_max` to be a triple of ints")


        self.save_config_on_exit = save_config_on_exit

        # Check parameters

        if initial_rotation is not None:
            if not np.allclose(initial_rotation @ initial_rotation.T, np.eye(3)):
                raise ValueError("Expected initial_rotation to be orthogonal")

            if not np.isclose(np.linalg.det(initial_rotation), 1):
                raise ValueError("Expected a rotation, not a rotoreflection")

        if initial_distance is not None and initial_distance <= 0:
            raise ValueError("Expected initial distance to be strictly positive")

        # Initialisation

        self._unique_id = _generate_unique_id()

        render_model = RenderModel(hamiltonian, copies, rotation_supercell_expansion_max,
                                   propagation_vector_commensurability_tolerance)

        layout = QVBoxLayout()

        self.toolbar = DisplayOptionsToolbar(
            initial_display_options=display_options,
            save_config_on_exit=self.save_config_on_exit,
            max_size_object_scaling=np.min(hamiltonian.structure.unit_cell.abc))

        splitter = QSplitter(Qt.Horizontal)
        self.viewer = CrystalViewerWidget(render_model, initial_rotation, initial_distance)
        self.text_display = TextDisplay(render_model)
        splitter.addWidget(self.viewer)
        splitter.addWidget(self.text_display)

        layout.addWidget(self.toolbar)
        layout.addWidget(splitter, stretch=1)

        self.setLayout(layout)

        #
        # Wire up settings
        #

        self.viewer.display_options = self.toolbar.display_options()
        self.toolbar.displayOptionsChanged.connect(self.on_display_options_changed)
        self.toolbar.requestViewReset.connect(self.on_reset_view_requested)
        self.toolbar.requestSnapshot.connect(self.on_snapshot_requested)

        #
        # Wire up text and graphics
        #

        self.text_display.hoverChanged.connect(self.on_text_hover_changed)
        self.text_display.selectionChanged.connect(self.on_text_selection_changed)
        self.viewer.hoverChanged.connect(self.on_render_hover_changed)
        self.viewer.selectionChanged.connect(self.on_render_selection_changed)

    def on_snapshot_requested(self):
        """Take a snapshot."""
        dialog = QFileDialog(self)
        dialog.setAcceptMode(QFileDialog.AcceptSave)
        dialog.setOption(QFileDialog.DontConfirmOverwrite, True)
        dialog.setNameFilters([
            "PNG Images (*.png)",
            "JPEG Images (*.jpg *.jpeg)",
            "All Files (*)"
        ])
        dialog.selectNameFilter("PNG Images (*.png)")
        dialog.setDefaultSuffix("png")
        dialog.setDirectory(QDir.currentPath())


        if dialog.exec():
            filename = dialog.selectedFiles()[0]
        else:
            return

        if not filename:
            # Cancelled
            return

        if os.path.exists(filename):
            # File exists

            result = QMessageBox.question(
                self,
                "Overwrite file?",
                "This file already exists, do you want to replace it",
                QMessageBox.Ok | QMessageBox.Cancel
            )

            if not result == QMessageBox.Ok:
                return

        self.save_snapshot(filename)


    def save_snapshot(self, filename):
        """Write the current viewer data to a file.

        Parameters
        ----------
        filename : str
            Output image file path.
        """
        data = self.viewer.snapshot()
        imwrite(filename, data)


    def on_display_options_changed(self):
        """Called when the toolbar changes."""
        self.viewer.display_options = self.toolbar.display_options()

    def on_text_hover_changed(self):
        """Called when mouse hovers over text components."""
        self.viewer.hover_ids = self.text_display.hover_ids

    def on_text_selection_changed(self):
        """Called when text components are selected."""
        self.viewer.current_selection = self.text_display.current_selection

    def on_render_hover_changed(self):
        """Called when hovering over graphical components."""
        self.text_display.set_hover(self.viewer.hover_ids)

    def on_render_selection_changed(self):
        """Called when selecting through the graphical window."""
        self.text_display.set_selection(self.viewer.current_selection)

    def on_reset_view_requested(self):
        """Called when a view reset is requested."""
        self.viewer.reset_view()

    def closeEvent(self, event):
        """Qt override for close event."""
        # Save settings on exit
        self.toolbar.save_settings()

        try:
            del _VIEWERS[self._unique_id]
        except Exception:
            pass

        super().closeEvent(event)


_APP = None
_VIEWERS = {}

def get_app():
    """Get the Qt instance.

    Returns
    -------
    QApplication
        Active Qt application instance.
    """
    global _APP #noqa: PLW0603
    app = QApplication.instance()
    if app is None:
        _APP = QApplication(sys.argv)
        app = _APP
    return app


def snapshot(object: Hamiltonian | Structure,
             filename: str | None = None,
             view_point: ArrayLike = (-5.0, -5.0, -10.0),
             display_options: DisplayOptions | None = None,
             copies: tuple[int,int,int]=(1,1,1),
             rotation_supercell_expansion_max: tuple[int,int,int]=(10,10,10),
             propagation_vector_commensurability_tolerance=1e-4):
    """Make (and display) an image of a structure/hamiltonian.

    If filename is not a string, it will create a matplotlib plot window.

    Parameters
    ----------
    object : Hamiltonian or Structure
        Hamiltonian or Structure object to show.
    filename : str or None, optional
        Output filename. If ``None``, displays the image via Matplotlib.
        Default is ``None``.
    view_point : array_like, optional
        Position of camera. Default is ``(-5.0, -5.0, -10.0)``.
    display_options : DisplayOptions or None, optional
        DisplayOptions object to affect settings, otherwise, it will use
        whatever the viewer is configured for. Default is ``None``.
    copies : tuple of (int, int, int), optional
        Supercell scaling along each lattice vector. Default is ``(1, 1, 1)``.
    rotation_supercell_expansion_max : tuple of (int, int, int), optional
        Maximum denominator along each axis when approximating a
        ``RotationSupercell`` propagation vector as a commensurate cell.
        Default is ``(10, 10, 10)``.
    propagation_vector_commensurability_tolerance : float, optional
        Tolerance for matching a propagation vector component to a rational
        fraction. Default is ``1e-4``.

    Returns
    -------
    matplotlib.image.AxesImage or None
        The Matplotlib image object if ``filename`` is ``None``, otherwise
        ``None``.

    Raises
    ------
    TypeError
        If ``object`` is not a ``Hamiltonian`` or ``Structure``.







    """
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("org.spinw.pyspinw")
    except Exception:
        pass

    if isinstance(object, Structure):
        object = Hamiltonian(object, [])

    if not isinstance(object, Hamiltonian):
        raise TypeError("Viewer needs to be given a Hamiltonian or Structure")

    # Parameters for setting the view
    view_point = np.array(view_point)
    rotation = rotation_from_z(view_point)
    distance = np.sqrt(np.sum(view_point**2))


    app = get_app()

    app.setWindowIcon(png_icon("pyspinw"))

    # Useful for checking particular display options
    # app.styleHints().setColorScheme(Qt.ColorScheme.Dark)
    # app.styleHints().setColorScheme(Qt.ColorScheme.Light)

    viewer = Viewer(object, rotation, distance, display_options,
                    save_config_on_exit=False, copies=copies,
                    rotation_supercell_expansion_max=rotation_supercell_expansion_max,
                    propagation_vector_commensurability_tolerance=propagation_vector_commensurability_tolerance)

    viewer.resize(800, 600)

    viewer.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)

    viewer.show()

    app.processEvents()

    # Force layout/polish/update
    viewer.ensurePolished()
    viewer.layout().activate()

    # If needed:
    viewer.repaint()

    # Make the widget paint
    # viewer.viewer.paintGL()

    data = viewer.viewer.snapshot()

    viewer.close()

    if filename is None:

        import matplotlib.pyplot as plt

        return plt.imshow(data)

    else:

        # Write to file
        imwrite(filename, data)


def show_object(object: Hamiltonian | Structure,
                block=True,
                copies: tuple[int,int,int]=(1,1,1),
                rotation_supercell_expansion_max: tuple[int,int,int]=(10,10,10),
                propagation_vector_commensurability_tolerance=1e-4):
    """Show a Hamiltonian or structure in the viewer.

    Parameters
    ----------
    object : Hamiltonian or Structure
        Hamiltonian or Structure object to display.
    block : bool, optional
        Whether to block execution by running the Qt event loop. Default is
        ``True``.
    copies : tuple of (int, int, int), optional
        Supercell scaling along each lattice vector. Default is ``(1, 1, 1)``.
    rotation_supercell_expansion_max : tuple of (int, int, int), optional
        Maximum denominator along each axis when approximating a
        ``RotationSupercell`` propagation vector as a commensurate cell.
        Default is ``(10, 10, 10)``.
    propagation_vector_commensurability_tolerance : float, optional
        Tolerance for matching a propagation vector component to a rational
        fraction. Default is ``1e-4``.

    Raises
    ------
    TypeError
        If ``object`` is not a ``Hamiltonian`` or ``Structure``.
    """
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("org.spinw.pyspinw")
    except Exception:
        pass

    if isinstance(object, Structure):
        object = Hamiltonian(object, [])

    if not isinstance(object, Hamiltonian):
        raise TypeError("Viewer needs to be given a Hamiltonian or Structure")

    app = get_app()

    app.setWindowIcon(png_icon("pyspinw"))

    # Useful for checking particular display options
    # app.styleHints().setColorScheme(Qt.ColorScheme.Dark)
    # app.styleHints().setColorScheme(Qt.ColorScheme.Light)

    viewer = Viewer(object, copies=copies,
                    rotation_supercell_expansion_max=rotation_supercell_expansion_max,
                    propagation_vector_commensurability_tolerance=propagation_vector_commensurability_tolerance)
    viewer.setWindowTitle("Hamiltonian Viewer")
    viewer.resize(800, 600)
    viewer.show()

    # Save a reference
    _VIEWERS[viewer._unique_id] = viewer

    if block:
        app.exec()
