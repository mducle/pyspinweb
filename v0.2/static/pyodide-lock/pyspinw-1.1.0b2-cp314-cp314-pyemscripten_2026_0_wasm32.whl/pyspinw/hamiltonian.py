"""Selection of different Hamiltonians."""
import logging
import warnings
from collections.abc import Callable
import re
from collections import Counter, defaultdict
from functools import reduce
from typing import Sequence, Union

import numpy as np

import matplotlib.pyplot as plt
from numpy._typing import ArrayLike

from pyspinw.calculations.energy_minimisation import ClassicalEnergyMinimisation, Free, \
    InitialRandomisation, Fixed, Planar
from pyspinw.calculations.spinwave import (
    spinwave_calculation as py_spinwave,
    Coupling as PyCoupling,
    MagneticField as PyMagneticField)

from pyspinw.anisotropy import Anisotropy
from pyspinw.cell_offsets import CellOffset, cell_offset_generator
from pyspinw.checks import check_sizes
from pyspinw.exchange import Exchange
from pyspinw.path import Path, Slice
from pyspinw.polarisation import calculate_polarised_intensity
from pyspinw.serialisation import SPWSerialisable, SPWSerialisationContext, SPWDeserialisationContext, expects_keys
from pyspinw.site import Site
from pyspinw.structure import Structure
from pyspinw.basis import site_rotations
from pyspinw.symmetry.operations import SpaceOperation
from pyspinw.symmetry.supercell import TiledSupercell, RotationSupercell
from pyspinw.units import IntensityUnits, intensity_units

# pylint: disable=R0903

logger = logging.Logger("pyspinw.hamiltonian")

def uniquetol(values: ArrayLike, tol: float=1e-5):
    """Return floating point unique values within a given tolerance.

    Parameters
    ----------
    values : array_like
        Input array of numeric values.
    tol : float, optional
        Tolerance within which values are considered equal. Default is ``1e-5``.

    Returns
    -------
    numpy.ndarray
        Unique values within the specified tolerance.
    """
    vabs = np.real(values) + np.imag(values)
    isrt = np.argsort(vabs)
    idif = np.append(True, np.diff(vabs[isrt]))
    return values[isrt[idif > tol]]

def omegasum(energy: ArrayLike, intensity: ArrayLike, tol: float=1e-5, zeroint: int=0, is_series: bool=True):
    """Remove degenerate and ghost (zero-intensity) modes from spectrum.

    Parameters
    ----------
    energy : array_like
        Mode energies at each q-point with shape ``(n_q, n_modes)``.
    intensity : array_like
        Mode intensities at each q-point with shape ``(n_q, n_modes)``.
    tol : float, optional
        Energy tolerance for grouping degenerate modes. Default is ``1e-5``.
    zeroint : int or float, optional
        Intensity threshold below which modes are treated as ghost modes.
        Default is ``0``.
    is_series : bool, optional
        Whether to maintain a consistent number of modes across q-points.
        Default is ``True``.

    Returns
    -------
    en_out : numpy.ndarray
        Degeneracy-merged mode energies with empty columns removed.
    int_out : numpy.ndarray
        Summed mode intensities corresponding to ``en_out``.
    """
    energy, intensity = (np.array(energy), np.array(intensity))
    en_out, int_out = (energy * np.nan, intensity * np.nan)
    if tol > 0:
        energy = np.round(energy / tol) * tol
    if zeroint > 0:
        energy[np.where(np.abs(np.real(intensity)) < zeroint)] = np.nan
    for iQ in range(energy.shape[0]):
        eu = uniquetol(energy[iQ,:])
        en_out[iQ,:len(eu)] = eu
        for iE in range(len(eu)):
            int_out[iQ, iE] = np.sum(intensity[iQ, np.where(np.abs(energy[iQ,:] - en_out[iQ, iE]) < tol)])
    nans = np.isnan(en_out)
    nanmodes = np.sum(nans, axis=0)
    if is_series:
        # Ensure there are the same number of modes throughout
        for col in set([int(idx) for accidentals in np.where((nanmodes > 0) * (nanmodes < en_out.shape[0]))[0]
                        for idx in np.where(nans[:,accidentals])[0]]):
            idnxt = 1 if col < en_out.shape[0]-1 else -1
            idnan = np.where(~np.isnan(en_out[col + idnxt,:]))[0]
            idx = np.array([np.nanargmin(np.abs(en_out[col + idnxt,i] - en_out[col])) for i in idnan])
            int_idx, bc = (int_out[col, np.where(~np.isnan(int_out[col,:]))], np.bincount(idx))
            if int_idx.shape[1] == len(bc) and all(bc > 0):
                en_out[col,idnan] = np.take(en_out[col, :], idx)
                int_out[col,idnan] = np.take(int_idx / bc, idx)
    # Removes columns which are all NaNs
    en_out = np.delete(en_out, np.where(nanmodes == en_out.shape[0])[0], axis=1)
    int_out = np.delete(int_out, np.where(nanmodes == en_out.shape[0])[0], axis=1)
    return en_out, int_out

def egrid(energy: ArrayLike, intensity: ArrayLike, evect: ArrayLike, dE: float | Callable):
    """Bin a set of energy/intensity into a spectrum with Gaussian broadening.

    Parameters
    ----------
    energy : array_like
        Mode energies at each q-point with shape ``(n_q, n_modes)``.
    intensity : array_like
        Mode intensities at each q-point with shape ``(n_q, n_modes)``.
    evect : array_like
        1D array of energy grid values.
    dE : float or callable
        Gaussian broadening full width at half maximum (FWHM), given as a scalar
        or a callable ``dE(evect)``.

    Returns
    -------
    numpy.ndarray
        Broadened 2D intensity spectrum with shape ``(n_q, len(evect))``.
    """
    energy, intensity = (np.real(np.array(energy)), np.array(intensity))
    esigma = dE(evect) if isinstance(dE, Callable) else np.ones(evect.shape) * dE
    esigma /= 2 * np.sqrt(2* np.log(2))  # Convert from FWHM
    spec = np.zeros((energy.shape[0], len(evect)))
    ew_norm = np.diff(evect, append=evect[-1] + (evect[-1] - evect[-2])) / (np.sqrt(2 * np.pi) * esigma)
    for iE in range(energy.shape[1]):
        spec += intensity[:,iE,np.newaxis] * ew_norm * \
            np.exp(-0.5 * ((evect[np.newaxis,:] - energy[:,iE,np.newaxis]) / esigma)**2)
    spec[np.where(spec < np.finfo(np.float32).eps)] = np.nan
    return spec

ParametrizationType = Union[str,
                       list[str],
                       list[tuple[Union[Exchange, Anisotropy, str], str]],
                       tuple[Sequence[Union[Exchange, Anisotropy, str]], str],
                       tuple[Exchange | Anisotropy | str, str]]

def _regularise_parameters(hamiltonian: "Hamiltonian", parameter_data: ParametrizationType):
    """Convert many options for defining parameters into a more regular form.

    This is used in the parameterisation method/class.

    Parameters
    ----------
    hamiltonian : Hamiltonian
        Hamiltonian instance used to resolve string exchange and anisotropy names.
    parameter_data : ParametrizationType
        Parameter definition given as a string, tuple, or list of strings/tuples.

    Returns
    -------
    exchanges : list of tuple of (Exchange, str)
        Resolved pairs of exchange objects and parameter names.
    anisotropies : list of tuple of (Anisotropy, str)
        Resolved pairs of anisotropy objects and parameter names.

    Raises
    ------
    ValueError
        If a tuple or string specification is invalid or no matching exchange or
        anisotropy is found.
    TypeError
        If ``parameter_data`` or its components have an unsupported type.
    Exception
        If an internal check on tuple conversion fails.
    """
    # Step 1: convert everything to a Sequence

    if isinstance(parameter_data, str):
        parameter_data = [parameter_data]

    elif isinstance(parameter_data, tuple):
        if len(parameter_data) != 2:
            raise ValueError(f"Expected tuple parameter definition to have length 2 (got {parameter_data})")

        if not isinstance(parameter_data[1], str):
            raise ValueError(f"Expected second component of tuple to be (got {type(parameter_data)}, {parameter_data})")

        if isinstance(parameter_data[0], Sequence):
            parameter_data = [(datum, parameter_data[1]) for datum in parameter_data[0]]

        elif isinstance(parameter_data[0], (Exchange, Anisotropy, str)):
            parameter_data = [parameter_data]

        else:
            raise TypeError(f"Expected parameters to be defined by Exchange, Anisotropy or str,"
                            f" got {type(parameter_data[0])}: {parameter_data[0]}")

    elif isinstance(parameter_data, list):
        pass

    else:
        raise TypeError(f"Expected to parameter definitions type to be str, Sequence, or tuple, "
                        f"got {type(parameter_data)}: {parameter_data}")

    #
    # Step 2: convert plain strings into tuples
    #

    new_parameter_data = []
    for datum in parameter_data:
        if isinstance(datum, str):
            parts = datum.split(".")

            if len(parts) != 2:
                raise ValueError(f"Expected strings to be of the form exchange_name.parameter_name, got '{datum}'")

            new_parameter_data.append((parts[0], parts[1]))

        else:
            new_parameter_data.append(datum)

    parameter_data = new_parameter_data

    #
    # Step 3: Check second part is always a string, and that tuples are the right length
    #

    for datum in parameter_data:
        if not isinstance(datum, tuple):
            raise Exception("A previous error has not been caught, parameters should all be tuples")

        if len(datum) != 2:
            raise ValueError(f"Expected all tuple entries to be length 2, found {datum}")

        if not isinstance(datum[1], str):
            raise ValueError(f"Expected second part of tuple to be a string, got {type(datum[1])}: {datum[1]}")

    #
    # Step 4: Resolve any string names, everything should now be tuple2
    #

    new_parameter_data = []
    for target, parameter in parameter_data:
        if isinstance(target, str):

            exchanges = hamiltonian.exchanges_by_name(target) + hamiltonian.anisotropies_by_name(target)

            if len(exchanges) == 0:
                raise ValueError(f"Could not find exchanges that match {target}")

            if len(exchanges) > 1:
                logger.warning(f"Found multiple matches for '{target}', attempting to use them all: {exchanges}")

            for exchange in exchanges:
                new_parameter_data.append((exchange, parameter))

        else:
            new_parameter_data.append((target, parameter))

    parameter_data = new_parameter_data

    #
    # Step 5: Split into exchanges and anisotopies
    #

    exchanges = []
    anisotropies = []
    for target, parameter in parameter_data:
        if isinstance(target, Exchange):
            exchanges.append((target, parameter))
        elif isinstance(target, Anisotropy):
            anisotropies.append((target, parameter))

    return exchanges, anisotropies


class Hamiltonian(SPWSerialisable):
    """Representation of a Hamiltonian - this could be considered the central class for pyspinw.

    ``Hamiltonian`` contain all the information needed to calculate the scattering for a given q in
    a unform material, and is composed of a ``Structure`` object, ``Exchange`` and ``Anisotropy``.

    The ``Hamiltonian`` object does not deal with non-uniform materials, such as powders or twins,
    these are specified with the ``Sample`` subclasses, which take ``Hamiltonian`` classes as inputs.

    Parameters
    ----------
    structure : Structure
        Magnetic structure containing the lattice sites, unit cell, spacegroup,
        and supercell.
    exchanges : list of Exchange
        Exchange interactions between sites in ``structure``.
    anisotropies : list of Anisotropy, optional
        Single-ion anisotropies on sites in ``structure``. Default is ``None``.

    Raises
    ------
    ValueError
        If any site referenced by ``exchanges`` or ``anisotropies`` is not in
        ``structure``.
    """

    serialisation_name = "hamiltonian"

    def __init__(self,
                 structure: Structure,
                 exchanges: list[Exchange],
                 anisotropies: list[Anisotropy] | None = None):

        anisotropies = [] if anisotropies is None else anisotropies

        # Check that exchanges and anisotropies refer to sites in the structure
        for exchange in exchanges:
            if exchange.site_1.unique_id not in structure._site_lookup:
                raise ValueError(f"Site 1 of {exchange} is not in the specified structure")
            if exchange.site_2.unique_id not in structure._site_lookup:
                raise ValueError(f"Site 2 of {exchange} is not in the specified structure")

        for anisotropy in anisotropies:
            if anisotropy.site.unique_id not in structure._site_lookup:
                raise ValueError(f"Site for {anisotropy} is not in the specified structure")

        self._structure = structure
        self._exchanges = exchanges
        self._anisotropies = anisotropies

    @property
    def structure(self):
        """Get the magnetic structure."""
        return self._structure

    @property
    def exchanges(self):
        """Get the exchanges."""
        return self._exchanges

    def exchanges_by_name(self, regex):
        """Get list of exchanges whose names match the regex.

        Parameters
        ----------
        regex : str
            Regular expression pattern matched against exchange names.

        Returns
        -------
        list of Exchange
            Exchanges whose names match ``regex``.
        """
        return [exchange for exchange in self.exchanges if re.match(regex, exchange.name) is not None]

    @property
    def anisotropies(self):
        """Get the anisotropies."""
        return self._anisotropies

    def anisotropies_by_name(self, regex):
        """Get list of anisotropies whose names match the regex.

        Parameters
        ----------
        regex : str
            Regular expression pattern matched against anisotropy names.

        Returns
        -------
        list of Anisotropy
            Anisotropies whose names match ``regex``.
        """
        return [anisotropy for anisotropy in self.anisotropies if re.match(regex, anisotropy.name) is not None]

    @property
    def text_summary(self) -> str:
        """String giving details of the system."""
        # lines = ["Sites:"]
        # for site in self.structure.sites:
        #     lines.append(f"  {site}")

        lines = [self.structure.text_summary]

        lines.append("Exchanges:")
        for exchange in self.exchanges:
            lines.append(f"  {exchange}") # vector =", exchange.vector(unit_cell=unit_cell))

        if self.anisotropies:
            lines.append("Anisotropies:")
            for anisotropy in self.anisotropies:
                lines.append(f"  {anisotropy}")

        return "\n".join(lines)




    def _expand_with_mapping(self, supercell_size: tuple[int, int, int] | None = None) -> \
            tuple[
                "Hamiltonian",
                dict[tuple[int, tuple[int, int, int]], Site],
                list[int],
                list[int]]:
        """Expand the supercell structure into a single cell structure and return the mapping between hamiltonians.

        This should only be used internally, and its not very user friendly.

        Parameters
        ----------
        supercell_size : tuple of (int, int, int), optional
            Supercell dimensions to expand into. If ``None``, the structure's
            supercell cell size is used. Default is ``None``.

        Returns
        -------
        hamiltonian : Hamiltonian
            Expanded single-cell Hamiltonian.
        site_mapping : dict of ((int, tuple of (int, int, int)), Site)
            Mapping from ``(original site UID, offset)`` to the expanded ``Site``.
        exchange_mapping : list of int
            Indices for the original exchanges corresponding to each expanded exchange.
        anisotropy_mapping : list of int
            Indices for the original anisotropies corresponding to each expanded anisotropy.
        """
        bigger_cell, site_mapping = self.structure._expansion_site_mapping(supercell_size)

        new_exchanges = []
        new_anisotropies = []

        if supercell_size is None:
            si, sj, sk = self.structure.supercell.cell_size()
        else:
            si, sj, sk = supercell_size

        exchange_mapping = []
        anisotropy_mapping = []

        for first_site_offset in cell_offset_generator(si, sj, sk):
            for original_index, exchange in enumerate(self.exchanges):
                # Convert the offset in the exchange, into
                #  1) an offset in the supercell, and
                #  2) an offset between supercells
                # basically just a divmod

                # Convert offsets into "absolute offsets"

                second_site_offset = exchange.cell_offset.vector + first_site_offset.vector

                oi, oj, ok = second_site_offset

                ni, ri = divmod(oi, si)
                nj, rj = divmod(oj, sj)
                nk, rk = divmod(ok, sk)

                new_cell_offset = CellOffset(ni, nj, nk)
                second_site_lookup_value = (ri, rj, rk)

                target_site_1 = site_mapping[(exchange.site_1.unique_id, first_site_offset.as_tuple)]
                target_site_2 = site_mapping[(exchange.site_2.unique_id, second_site_lookup_value)]

                # Create the new exchange using their update method, which copies everything not specified
                new_exchanges.append(
                    exchange.updated(
                        site_1=target_site_1,
                        site_2=target_site_2,
                        cell_offset=new_cell_offset))

                # Add entry to mapping
                exchange_mapping.append(original_index)

            for original_index, anisotropy in enumerate(self.anisotropies):
                target_site = site_mapping[(anisotropy.site.unique_id, first_site_offset.as_tuple)]

                # Update-copy anisotropy
                new_anisotropies.append(anisotropy.updated(site=target_site))

                # Add entry to mapping
                anisotropy_mapping.append(original_index)

        structure = Structure(
            sites=[site for site in site_mapping.values()],
            unit_cell=bigger_cell,
            spacegroup=self.structure.spacegroup.for_supercell(self.structure.supercell),
            supercell=TiledSupercell(scaling=(1, 1, 1)),
            show_unit_cell_warning=False,
        )

        return (Hamiltonian(
                    structure=structure,
                    exchanges=new_exchanges,
                    anisotropies=new_anisotropies,
                    ),
                site_mapping, exchange_mapping, anisotropy_mapping)

    def expanded(self, supercell_size: tuple[int, int, int] | None = None):
        """Expand the supercell structure into a single cell structure.

        Parameters
        ----------
        supercell_size : tuple of (int, int, int), optional
            Supercell dimensions to expand into. Default is ``None``.

        Returns
        -------
        Hamiltonian
            Expanded single-cell Hamiltonian.

        Raises
        ------
        TypeError
            If ``supercell_size`` is not a length-3 tuple.
        """
        if supercell_size is not None:
            if not isinstance(supercell_size, tuple):
                raise TypeError("supercell_size should be a tuple")
            if len(supercell_size) != 3:
                raise TypeError("supercell_size should be a length 3 tuple")

            supercell_size = tuple(int(x) for x in supercell_size)

        if isinstance(self.structure.supercell, RotationSupercell):
            if supercell_size is None:
                logger.warning("Expanding an incommensurate structure requires a supercell_size parameter, "
                              "or it will make a 1x1x1 supercell")
        else:
            if supercell_size is not None:
                logger.warning("You are overriding the supercell size in a commensurate structure")

        expanded, _, _, _ = self._expand_with_mapping(supercell_size)
        return expanded

    def without_nonmagnetic(self):
        """Get a copy of this Hamiltonian with the nonmagnetic sites removed.

        Returns
        -------
        Hamiltonian
            Hamiltonian with all nonmagnetic sites and their associated exchanges
            and anisotropies removed.
        """
        new_structure, removed_uids = self.structure._without_nonmagnetic_with_removed_uids()

        new_exchanges = [exchange for exchange in self.exchanges
                         if exchange.site_1.unique_id not in removed_uids and
                            exchange.site_2.unique_id not in removed_uids]

        new_anisotropies = [anisotropy for anisotropy in self.anisotropies
                            if anisotropy.site.unique_id not in removed_uids]

        return Hamiltonian(new_structure, new_exchanges, new_anisotropies)

    def sites_by_name(self, test_string) -> list[Site]:
        """Get sites where name matches regex.

        Parameters
        ----------
        test_string : str
            Regular expression pattern matched against site names.

        Returns
        -------
        list of Site
            Sites whose names match ``test_string``.
        """
        return self.structure.sites_by_name(test_string)

    def print_summary(self):
        """Print a textual summary to stdout."""
        print(self.text_summary)

    @check_sizes(field=(3,), allow_nones=True, force_numpy=True)
    def energies_and_intensities(self,
                                 path: Path,
                                 field: ArrayLike | None = None,
                                 use_rust: bool=True,
                                 use_rotating: bool=True,
                                 intensity_unit: IntensityUnits | str='cell',
                                 components: str='Sperp',
                                 ):
        """Calculate the energy levels and intensities of the system for the given q-vectors.

        Parameters
        ----------
        path : Path
            Path along which to calculate.
        field : array_like, optional
            Magnetic field vector, in tesla. Default is ``None``.
        use_rust : bool, optional
            Whether to use Rust or Python calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Whether to normalise intensity per unit cell or spin. Default is ``'cell'``.
        components : str, optional
            Whether to compute a particular polarised neutron component. Default is
            ``'Sperp'``; for the accepted strings, including ``'all'``, see
            :func:`pyspinw.polarisation.calculate_polarised_intensity`.

        Returns
        -------
        energies : numpy.ndarray
            Calculated mode energies at each q-point.
        intensities : numpy.ndarray or list of numpy.ndarray or tuple
            Calculated mode intensities at each q-point.
        """
        return self.without_nonmagnetic()._energies_and_intensities(
            q_vectors=path.q_points(),
            field=field,
            use_rust=use_rust,
            use_rotating=use_rotating,
            intensity_unit=intensity_unit,
            components=components)


    @check_sizes(q_vectors=(-1, 3), field=(3,), allow_nones=True, force_numpy=True)
    def _energies_and_intensities(self,
                              q_vectors: np.ndarray,
                              field: ArrayLike | None = None,
                              use_rust: bool=True,
                              use_rotating: bool=True,
                              intensity_unit: IntensityUnits | str='cell',
                              components: str='Sperp'
                              ) -> tuple[np.ndarray, np.ndarray]:
        """Calculate the energy levels of the system for the given q-vectors.

        Does not remove nonmagnetic sites.

        Parameters
        ----------
        q_vectors : (N, 3) numpy.ndarray
            An array of q-vectors.
        field : array_like, optional
            Magnetic field vector, in tesla. Default is ``None``.
        use_rust : bool, optional
            Whether to use Rust or Python calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Whether to normalise intensity per unit cell or spin. Default is ``'cell'``.
        components : str, optional
            Whether to compute a particular polarised neutron component. Default is
            ``'Sperp'``.

        Returns
        -------
        energies : numpy.ndarray
            Calculated mode energies at each q-point.
        intensities : numpy.ndarray or list of numpy.ndarray or tuple
            Calculated mode intensities at each q-point.
        """
        #
        # Set up choice of calculation
        #
        save_sab = components != 'Sperp'

        energies, intensities, sab, _, scaling, rlu_to_cart = self._spinwave_calculation(
            q_vectors=q_vectors,
            field=field,
            use_rust=use_rust,
            use_rotating=use_rotating,
            intensity_unit=intensity_unit,
            save_sab=save_sab,
        )

        if save_sab:
            intensities = calculate_polarised_intensity(sab, intensities, q_vectors * scaling,
                                                      components, rlu_to_cart)
            # 'all' gives the tuple (Pab, Pa, Mab), whose complex parts carry the chiral terms
            if not isinstance(intensities, tuple):
                intensities = intensities.real

        return energies, intensities

    def spinwave_calculation(self,
                          path: Path,
                          field: ArrayLike | None = None,
                          use_rust: bool = True,
                          use_rotating: bool = True,
                          intensity_unit: IntensityUnits | str = 'cell',
                          save_sab: bool = False,
                          save_wavefunctions: bool = False
                          ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Perform a spin wave calculation of the system for the given q-point path.

        Parameters
        ----------
        path : Path
            Path along which to calculate.
        field : array_like, optional
            Magnetic field vector, in tesla. Default is ``None``.
        use_rust : bool, optional
            Whether to use Rust or Python calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Whether to normalise intensity per unit cell or spin. Default is ``'cell'``.
        save_sab : bool, optional
            Whether to return the Sab matrices. Default is ``False``.
        save_wavefunctions : bool, optional
            Whether to return the eigenvectors at each Q-point. Default is ``False``.

        Returns
        -------
        energies : numpy.ndarray
            Calculated mode energies at each q-point.
        intensities : list of numpy.ndarray
            Calculated mode intensities at each q-point.
        sab : numpy.ndarray or None
            Spin-spin correlation matrices if ``save_sab`` is ``True``, otherwise ``None``.
        wavefunctions : numpy.ndarray or None
            Eigenvectors at each q-point if ``save_wavefunctions`` is ``True``,
            otherwise ``None``.
        """
        energies, intensities, sab, wavefunctions, scaling, rlu_to_cart = \
            self.without_nonmagnetic()._spinwave_calculation(
                q_vectors=path.q_points(),
                field=field,
                use_rust=use_rust,
                use_rotating=use_rotating,
                intensity_unit=intensity_unit,
                save_sab=save_sab,
                save_wavefunctions=save_wavefunctions)


        return energies, intensities, sab, wavefunctions

    def _spinwave_calculation(self,
                              q_vectors: np.ndarray,
                              field: ArrayLike | None = None,
                              use_rust: bool=True,
                              use_rotating: bool=True,
                              intensity_unit: IntensityUnits | str='cell',
                              save_sab: bool=False,
                              save_wavefunctions: bool=False
                              ):
        """Calculate the energy levels of the system for the given q-vectors.

        Does not remove nonmagnetic sites.

        Parameters
        ----------
        q_vectors : (N, 3) numpy.ndarray
            An array of q-vectors.
        field : array_like, optional
            Magnetic field vector, in tesla. Default is ``None``.
        use_rust : bool, optional
            Whether to use Rust or Python calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Whether to normalise intensity per unit cell or spin. Default is ``'cell'``.
        save_sab : bool, optional
            Whether to return the Sab matrices. Default is ``False``.
        save_wavefunctions : bool, optional
            Whether to return the eigenvectors at each Q-point. Default is ``False``.

        Returns
        -------
        energies : numpy.ndarray
            Calculated mode energies at each q-point.
        intensities : list of numpy.ndarray
            Calculated mode intensities at each q-point.
        sab : numpy.ndarray or None
            Spin-spin correlation matrices if ``save_sab`` is ``True``, otherwise ``None``.
        wavefunctions : numpy.ndarray or None
            Eigenvectors at each q-point if ``save_wavefunctions`` is ``True``,
            otherwise ``None``.
        scaling : float or tuple of (int, int, int)
            Supercell scaling factor applied to ``q_vectors``.
        rlu_to_cart : (3, 3) numpy.ndarray
            Transformation matrix from reciprocal lattice units to Cartesian coordinates.

        Raises
        ------
        NotImplementedError
            If ``intensity_unit`` is ``BARNPERATOM`` or ``BARNPERCELL``.
        """
        intensity_unit = intensity_units(intensity_unit)
        if intensity_unit == IntensityUnits.BARNPERATOM or intensity_unit == IntensityUnits.BARNPERCELL:
            raise NotImplementedError('Intensity scale in barn/sr/meV/atom not yet implemented.')



        # Rotating frame calculations should only be run on RotationSupercells
        use_rotating = use_rotating and isinstance(self.structure.supercell, RotationSupercell)

        # default to Python unless Rust is requested (which it is by default) and available
        coupling_class = PyCoupling

        spinwave_calculation = py_spinwave
        magnetic_field_class = PyMagneticField

        if use_rust:
            try:
                from pyspinw.rust import (
                    spinwave_calculation as rs_spinwave,
                    Coupling as RsCoupling,
                    MagneticField as RsMagneticField)

                coupling_class = RsCoupling
                spinwave_calculation = rs_spinwave
                magnetic_field_class = RsMagneticField


            except ModuleNotFoundError:
                # Silently don't use rust, maybe should give a warning though
                logger.warning("Failed to load rust core, falling back to python")
                use_rust = False

        else:
            logger.info("Using Python core code")

        rust_kw = {'dtype': complex, 'order': 'F'}

        #
        # Set up the system
        #
        if all([hasattr(self.structure.supercell, v) for v in ['propagation_vector', 'perpendicular']]):
            if use_rotating:
                expanded, scaling = (self, 1.)
                nvec = self.structure.supercell.perpendicular
                rotating_frame = [self.structure.supercell.propagation_vector._vector, nvec / np.linalg.norm(nvec)]
            else:
                newstruc = Structure(**{k:getattr(self.structure, k) for k in ['sites', 'unit_cell', 'spacegroup']},
                               supercell=self.structure.supercell.approximant())
                expanded = Hamiltonian(newstruc, self.exchanges, self.anisotropies).expanded()
                scaling, rotating_frame = (newstruc.supercell.cell_size(), None)
        else:
            if use_rotating:
                logger.warning("Cannot do rotating frame calculation propagation vector or plane normal not specified")
            expanded, scaling, rotating_frame = (self.expanded(), self.structure.supercell.cell_size(), None)

        # Get the positions, rotations, spins for the sites
        spins = []
        positions = []
        unique_id_to_index: dict[int, int] = {}
        for index, site in enumerate(expanded.structure.sites):

            spins.append(site.base_spin)
            positions.append(site.ijk)
            unique_id_to_index[site._unique_id] = index

        # Get the field object
        if field is None:
            magnetic_field = None
        else:
            g_tensors = []
            for site in expanded.structure.sites:
                g_tensors.append(site.g)
            # Factor 2 in field below to agree with Matlab code (like with SIA term in L474)
            magnetic_field = magnetic_field_class(
                                vector=2.0 * np.array(field, **rust_kw),
                                g_tensors=np.array(g_tensors, **rust_kw))

        spins = np.array(spins, dtype=float)
        rotations = site_rotations(spins)
        magnitudes = np.sqrt(np.sum(spins**2, axis=1))
        rotations = np.array([rotations[i, :, :] for i in range(rotations.shape[0])], **rust_kw)

        # Convert the couplings
        couplings: list[Exchange] = []
        for input_exchange in expanded.exchanges:
            # Normal coupling

            coupling = coupling_class(
                unique_id_to_index[input_exchange.site_1._unique_id],
                unique_id_to_index[input_exchange.site_2._unique_id],
                np.array(input_exchange.exchange_matrix, **rust_kw),
                input_exchange.cell_offset.vector.astype('double')
            )

            couplings.append(coupling)

            # Reversed coupling

            coupling = coupling_class(
                unique_id_to_index[input_exchange.site_2._unique_id],
                unique_id_to_index[input_exchange.site_1._unique_id],
                np.array(input_exchange.exchange_matrix.T, **rust_kw),
                -input_exchange.cell_offset.vector.astype('double')
            )

            couplings.append(coupling)

        ## This shouldn't be needed now things are (probably) fixed - keeping in case
        # Remove duplicate couplings
        # couplings = [c1 for ic, c1 in enumerate(couplings)
        #              if all([c1 != c2 for c2 in couplings[ic+1:]])]

        # Add in anisotropies as spinwave_calculation couplings
        for input_anisotropy in expanded.anisotropies:

            anisotropy = coupling_class(
                unique_id_to_index[input_anisotropy.site._unique_id],
                unique_id_to_index[input_anisotropy.site._unique_id],
                # Factor 2 here is to agree with Matlab code (need to check if is correct)
                np.array(input_anisotropy.anisotropy_matrix.T, **rust_kw) * 2.,
                inter_site_vector=np.array([0,0,0], dtype=float)
            )

            couplings.append(anisotropy)

        rlu_to_cart = np.linalg.inv(expanded.structure.unit_cell._xyz).T * 2 * np.pi
        result = spinwave_calculation(
                        rotations=rotations,
                        magnitudes=magnitudes,
                        q_vectors=q_vectors * scaling,
                        couplings=couplings,
                        positions=positions,
                        rlu_to_cart=rlu_to_cart,
                        field=magnetic_field,
                        rotating_frame=rotating_frame,
                        save_sab=save_sab,
                        save_wavefunctions=save_wavefunctions)

        energies, intensities, sab, wavefunctions = result

        if sab is not None and use_rust:
            sab = np.transpose(sab, (3, 2, 1, 0))

        # Applies a rescaling to agree with Matlab code for Sab
        # Toth & Lake eq (46) gives a 1/(2Natom) prefactor but the Matlab code uses 1/(2*Ncell)
        if intensity_unit == IntensityUnits.PERCELL:
            scale_factor = rotations.shape[0] / np.prod(scaling)
            intensities = [res * scale_factor for res in intensities]
            if sab is not None:
                sab = sab * scale_factor

        return energies, intensities, sab, wavefunctions, scaling, rlu_to_cart

    def spaghetti_plot_dual(self,
                            path: Path,
                            field: ArrayLike | None = None,
                            show: bool=True,
                            new_figure: bool=True,
                            use_rust: bool=True,
                            use_rotating: bool=True,
                            intensity_unit: IntensityUnits | str = 'cell',
                            scale: str='linear',
                            components: str='Sperp'):
        """Create a spaghetti diagram with energy top and intensity bottom.

        Parameters
        ----------
        path : Path
            Path in reciprocal space along which to plot.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        show : bool, optional
            Whether to display the plot with ``plt.show()``. Default is ``True``.
        new_figure : bool, optional
            Whether to create a new Matplotlib figure. Default is ``True``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Intensity normalisation unit. Default is ``'cell'``.
        scale : str, optional
            Y-axis scale for the intensity subplot (e.g. ``'linear'`` or ``'log'``).
            Default is ``'linear'``.
        components : str, optional
            Polarised neutron component to compute. Default is ``'Sperp'``.

        Returns
        -------
        matplotlib.figure.Figure or None
            Matplotlib figure if ``show`` is ``False``, otherwise ``None``.
        """
        if new_figure:
            fig, axs = plt.subplots(2, 1)
        else:
            fig = plt.gcf()
            axs = fig.get_axes()
            for ii in range(len(axs), 2):
                axs.append(fig.add_subplot(2,1,ii+1))

        x_values = path.x_values()
        energy, intensity = omegasum(*self._energies_and_intensities(path.q_points(), field, use_rust, use_rotating,
                                                                     intensity_unit, components))
        n_mode = energy.shape[1]
        for series in zip(*([v[:, n_mode - i - 1] for i in range(n_mode)] for v in (energy, intensity))):
            axs[0].plot(x_values, np.real(series[0]), 'k')
            axs[1].plot(x_values, np.real(series[1]), 'k')
            if (np.imag(series[0]) > 0.01).any():
                axs[0].plot(x_values, np.imag(series[0]), 'or')
        if 'log' in scale:
            axs[1].set_yscale('log')
        axs[0].set_ylabel('Magnon Energy (meV)')
        axs[1].set_ylabel('Magnon Intensity')

        path.format_plot(axs[0])
        path.format_plot(axs[1])

        if show:
            plt.show()
        else:
            return fig

    def spaghetti_plot(self,
                       path: Path,
                       evect: ArrayLike | None = None,
                       dE: float | Callable | None = None,
                       vmin: float=0,
                       vmax: float | None = None,
                       field: ArrayLike | None = None,
                       show: bool=True,
                       new_figure: bool=True,
                       use_rust: bool=True,
                       use_rotating: bool=True,
                       intensity_unit: IntensityUnits | str = 'cell',
                       scale: str='linear',
                       components: str='Sperp'):
        """Create a spaghetti diagram with intensity as colorfill overplotted by mode energies.

        Parameters
        ----------
        path : Path
            Path in reciprocal space along which to plot.
        evect : array_like, optional
            1D array of energy grid points. If ``None``, an automatic range is
            constructed. Default is ``None``.
        dE : float or callable, optional
            Gaussian energy broadening FWHM. If ``None``, a default based on
            ``evect`` spacing is used. Default is ``None``.
        vmin : float, optional
            Minimum value of the colour scale. Default is ``0``.
        vmax : float, optional
            Maximum value of the colour scale. If ``None``, determined automatically.
            Default is ``None``.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        show : bool, optional
            Whether to display the plot with ``plt.show()``. Default is ``True``.
        new_figure : bool, optional
            Whether to create a new Matplotlib figure. Default is ``True``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Intensity normalisation unit. Default is ``'cell'``.
        scale : str, optional
            Intensity scale specification. Default is ``'linear'``.
        components : str, optional
            Polarised neutron component to compute. Default is ``'Sperp'``.

        Returns
        -------
        matplotlib.figure.Figure or None
            Matplotlib figure if ``show`` is ``False``, otherwise ``None``.
        """
        if new_figure:
            fig, ax = plt.subplots()
        else:
            fig = plt.gcf()
            ax = fig.get_axes()[0]

        x_values = path.x_values()
        energy, intensity = omegasum(*self._energies_and_intensities(path.q_points(), field, use_rust, use_rotating,
                                                                     intensity_unit, components))
        intensity[np.where(np.isnan(intensity))] = 0
        energy[np.where(np.isnan(energy))] = 0
        if evect is None:
            emax = max(0.0001, np.nanmax(np.real(energy)))
            denom = 10**np.floor(np.log10(emax))
            evect = np.linspace(0, np.ceil(emax / denom) * denom, 100)
        if dE is None:
            dE = np.mean(np.diff(evect)) * 2.35
        spec = egrid(energy, intensity, evect, dE)
        if vmax is None:
            try:
                vmax = np.nanmax(spec[:, np.where(evect > max(np.max(evect)/10, 0.1))]) / 10.
            except ValueError:
                vmax = 1 # ??????

        if dE != 0:
            mesh = ax.pcolormesh(x_values, evect, spec.T, vmin=vmin, vmax=vmax, cmap="magma_r")
            fig.colorbar(mesh, ax=ax)

        ax.plot(x_values, np.real(energy), 'k')
        if (np.imag(energy) > 0.01).any():
            ax.plot(x_values, np.imag(energy), 'or')
        ax.set_ylim(0, np.max(evect))
        path.format_plot(ax)
        ax.set_ylabel('Magnon Energy (meV)')

        if show:
            plt.show()
        else:
            return fig

    def intensity_map(self,
                            q_slice: Slice,
                            vmin: float = 0,
                            vmax: float | None = None,
                            field: ArrayLike | None = None,
                            show: bool = True,
                            new_figure: bool = True,
                            use_rust: bool = True,
                            use_rotating: bool = True,
                            intensity_unit: IntensityUnits | str = 'cell',
                            cmap: str = "magma_r",
                            origin: str = "lower"):
        """Plot a reciprocal space map with intensity integrated over energy.

        Parameters
        ----------
        q_slice : Slice
            2D slice object defining the grid of q-points. Energy bounds ``e_min``
            and ``e_max`` (in meV) are taken from this object.
        vmin : float, optional
            Minimum color scale limit. Default is ``0``.
        vmax : float, optional
            Maximum color scale limit. If ``None``, determined automatically.
            Default is ``None``.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        show : bool, optional
            Whether to display the plot. Default is ``True``.
        new_figure : bool, optional
            Whether to create a new figure. Default is ``True``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.
        use_rotating : bool, optional
            Whether to use the rotating frame calculator if possible. Default is ``True``.
        intensity_unit : IntensityUnits or str, optional
            Intensity normalisation unit. Default is ``'cell'``.
        cmap : str, optional
            Matplotlib colormap name. Default is ``"magma_r"``.
        origin : str, optional
            ``'lower'`` or ``'upper'`` for Matplotlib ``imshow`` origin. Default is
            ``"lower"``.

        Returns
        -------
        matplotlib.figure.Figure or None
            Matplotlib figure if ``show`` is ``False``, otherwise ``None``.
        """
        if new_figure:
            fig, ax = plt.subplots()
        else:
            fig = plt.gcf()
            ax = fig.get_axes()[0]

        # Get energy bounds from the Slice object
        e_min = q_slice.e_min
        e_max = q_slice.e_max

        # Step 1: Calculate all energies and intensities at each q-point
        energies, intensities = self._energies_and_intensities(
            q_slice.q_points(),
            field=field,
            use_rust=use_rust,
            use_rotating=use_rotating,
            intensity_unit=intensity_unit
        )

        # Step 2: Convert to numpy arrays and nan is counted as 0
        energies = np.array(energies)
        intensities = np.array(intensities)

        energies = np.nan_to_num(energies, nan=0.0)
        intensities = np.nan_to_num(intensities, nan=0.0)


        # Step 3: Energy integration - mask and sum
        mask = energies > 0  # Only positive energy modes
        if e_min is not None:
            mask &= energies >= e_min
        if e_max is not None:
            mask &= energies <= e_max

        # Sum over all modes within the energy window
        integrated = np.sum(intensities * mask, axis=1)  # shape = (n_q,)

        # Step 4: Reshape back to 2D grid
        # meshgrid(indexing="xy") lays out data as (n_b, n_a) in memory
        # imshow expects shape (rows, cols) = (n_b, n_a) where rows = vertical/axis_2
        grid_data = integrated.reshape(q_slice.n_b, q_slice.n_a)

        # Step 5: Auto-scale color limits if not provided
        if vmax is None:
            vmax = np.nanmax(grid_data)

        # Step 6: Plot heatmap
        im = ax.imshow(
            grid_data,
            extent=q_slice.extent(),
            origin=origin,
            vmin=vmin,
            vmax=vmax,
            cmap=cmap,
            aspect="auto"
        )

        # Step 7: Add colorbar and labels
        fig.colorbar(im, ax=ax, label="Intensity")
        q_slice.format_plot(ax)

        # Add title showing energy window
        if e_min is not None and e_max is not None:
            ax.set_title(f"Reciprocal Space Map (E = {e_min:.0f}-{e_max:.0f} meV)")
        elif e_min is not None:
            ax.set_title(f"Reciprocal Space Map (E > {e_min:.0f} meV)")
        elif e_max is not None:
            ax.set_title(f"Reciprocal Space Map (E < {e_max:.0f} meV)")
        else:
            ax.set_title("Reciprocal Space Map (all energies)")

        fig.tight_layout()

        if show:
            plt.show()
        else:
            return fig

    def parameterize(self,
                     *parameters: ParametrizationType,
                     find_ground_state_with: dict | None = None) -> "HamiltonianParameterization":
        """Get a function that maps floats to a hamiltonian with the floats controlling the specified parameters.

        Parameters
        ----------
        *parameters : ParametrizationType
            Parameter specifications identifying exchange or anisotropy attributes to vary.
        find_ground_state_with : dict, optional
            Keyword arguments passed to :meth:`ground_state` when evaluating the
            parameterized Hamiltonian. Default is ``None``.

        Returns
        -------
        HamiltonianParameterization
            Callable parameterization of this Hamiltonian.
        """
        return HamiltonianParameterization(self,*parameters,
                                           find_ground_state_with=find_ground_state_with)

    def sorted_positive_energies(self,
                                 path: Path,
                                 field: ArrayLike | None = None,
                                 use_rust: bool = True) -> list[np.ndarray]:
        """Return energies as series corresponding to q, sorted by energy.

        Parameters
        ----------
        path : Path
            Path in reciprocal space along which to calculate energies.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.

        Returns
        -------
        list of numpy.ndarray
            Sorted positive energy series along ``path``.
        """
        return self._sorted_positive_energies(path.q_points(), field=field, use_rust=use_rust)

    def _sorted_positive_energies(self,
                                  q_vectors: np.ndarray,
                                  field: ArrayLike | None = None,
                                  use_rust: bool = True) -> list[np.ndarray]:
        """Return energies as series corresponding to q, sorted by energy, for an array of q-vectors.

        Parameters
        ----------
        q_vectors : (N, 3) numpy.ndarray
            Array of q-vectors in reciprocal lattice units.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.

        Returns
        -------
        list of numpy.ndarray
            Sorted positive energy series for ``q_vectors``.
        """
        energy, intensities = self._energies_and_intensities(q_vectors, field=field, use_rust=use_rust)

        energy = np.array(energy)

        # Sort the energies
        energy = np.sort(energy.real, axis=1)

        # return the top half (positive)
        n_energies = energy.shape[1]
        energies = [energy[:, n_energies - i - 1] for i in range(n_energies//2)]

        return energies

    def energy_plot(self,
                    path: Path,
                    field: ArrayLike | None = None,
                    show: bool=True,
                    new_figure: bool=True,
                    use_rust: bool=True):
        """Create a spaghetti diagram.

        Parameters
        ----------
        path : Path
            Path in reciprocal space along which to plot mode energies.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        show : bool, optional
            Whether to display the plot with ``plt.show()``. Default is ``True``.
        new_figure : bool, optional
            Whether to create a new figure. Default is ``True``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.
        """
        if new_figure:
            fig = plt.figure("Energy")
        else:
            fig = plt.gcf()

        x_values = path.x_values()

        for series in self.sorted_positive_energies(path, field=field, use_rust=use_rust):
            plt.plot(x_values, series, 'k')

        path.format_plot(plt)

        if show:
            plt.show()
        else:
            return fig

    def ground_state(self,
                     fixed: list[Site] | None = None,
                     planar: list[Site | tuple[Site, ArrayLike]] | None = None,
                     planar_axis: ArrayLike | None = None,
                     field: ArrayLike | None = None,
                     step_size: float = 0.1,
                     initial_randomisation: InitialRandomisation | str = InitialRandomisation.JITTER,
                     seed: int | None = None,
                     rtol: float=1e-10,
                     atol: float=1e-12,
                     max_iters: int=1000,
                     verbose: bool=True):
        """Get the classical ground state via gradient descent.

        For more direct control, use the
        :py:class:`~pyspinw.calculations.energy_minimisation.ClassicalEnergyMinimisation` class

        Parameters
        ----------
        fixed : list of Site, optional
            List of sites that should be ignored by the minimisation, i.e. fixed in
            place. Default is ``None``.
        planar : list of (Site or tuple of (Site, array_like)), optional
            List of sites, or ``(site, axis)`` tuples that should be constrained to a
            plane. Default is ``None``.
        planar_axis : array_like, optional
            Axis to use for planar constraints if not specified explicitly. Default is
            ``[0, 0, 1]``.
        field : array_like, optional
            Magnetic field applied, in tesla. Default is ``None``.
        step_size : float, optional
            Size of step to make relative to the force; smaller values than the default
            might be needed for systems with high energy. Default is ``0.1``.
        initial_randomisation : InitialRandomisation or str, optional
            Option to ``RANDOMISE`` or ``JITTER`` the starting state, or ``NONE``.
            Default is ``InitialRandomisation.JITTER``.
        seed : int, optional
            Seed to use in any randomisation steps. Default is ``None``.
        rtol : float, optional
            Convergence criterion; stop when ``[energy change] < rtol * [initial energy change]``.
            Default is ``1e-10``.
        atol : float, optional
            Convergence criterion; stop when ``[energy change] < atol``. Default is
            ``1e-12``.
        max_iters : int, optional
            Limit on the number of iterations. Default is ``1000``.
        verbose : bool, optional
            Print information about the process to stdout. Default is ``True``.

        Returns
        -------
        Hamiltonian
            A new :class:`Hamiltonian` with optimised spin state.

        Raises
        ------
        ValueError
            If any tuple in ``planar`` does not have length 2.
        TypeError
            If entries in ``planar`` are not ``Site`` instances or valid
            ``(Site, array_like)`` tuples.
        """
        #
        # Build the constraints
        #

        # Deal with defaults
        default_axis = np.array([0,0,1]) if planar_axis is None else np.array(planar_axis)
        fixed = [] if fixed is None else fixed
        planar = [] if planar is None else planar

        # Mapping
        site_uid_lookup = {site.unique_id: index for index, site in enumerate(self.structure.sites)}


        # Actual building
        constraints = [Free for _ in self.structure.sites]

        for site in fixed:
            constraints[site_uid_lookup[site.unique_id]] = Fixed

        for site_or_tuple in planar:

            if isinstance(site_or_tuple, Site):
                index = site_uid_lookup[site_or_tuple.unique_id]
                constraints[index] = Planar(default_axis)

            elif isinstance(site_or_tuple, tuple):

                if len(site_or_tuple) != 2:
                    raise ValueError("Expected tuples in `planar` to be length 2")

                if not isinstance(site_or_tuple[0], Site):
                    raise TypeError("Expected first component of tuples to be a LatticeSite")

                try:
                    axis = np.array(site_or_tuple[1])
                except Exception:
                    raise TypeError("Expected second component of tuples to be an array")

                index = site_uid_lookup[site_or_tuple[0].unique_id]
                constraints[index] = Planar(axis)

            else:
                raise TypeError("Expected entries in planar to be sites, or tuples of sites and axes")

        #
        # Run the minimisation
        #

        minimiser = ClassicalEnergyMinimisation(self, constraints, field, seed)
        minimiser.minimise(
            rtol=rtol,
            atol=atol,
            max_iters=max_iters,
            initial_randomisation=initial_randomisation,
            step_size=step_size,
            verbose=verbose)


        # Create new spins
        old_uid_to_new_site = {}
        new_sites = []
        for site_index, site in enumerate(minimiser.sites):
            spin_data = minimiser.spin_data[site_index, :, :]

            old_uid = site.unique_id
            new_site = Site(site.i, site.j, site.k,
                            supercell_spins=spin_data,
                            g=site.g, name=site.name)

            new_sites.append(new_site)
            old_uid_to_new_site[old_uid] = new_site

        # Convert input sites too
        new_input_sites = [old_uid_to_new_site[site.unique_id] for site in minimiser.hamiltonian.structure._input_sites]

        structure = Structure(new_input_sites,
                 unit_cell=minimiser.hamiltonian.structure.unit_cell,
                 spacegroup=minimiser.hamiltonian.structure.spacegroup,
                 supercell=minimiser.hamiltonian.structure.supercell,
                 skip_checks=False,
                 show_unit_cell_warning=False,
                 assume_symmetric_sites_are_provided=True,
                 cooerce_spin_data_to_match_supercell=False,
                 symmetric_sites=new_sites)

        exchanges = [exchange.updated(
            site_1=old_uid_to_new_site[exchange.site_1.unique_id],
            site_2=old_uid_to_new_site[exchange.site_2.unique_id])
            for exchange in minimiser.hamiltonian.exchanges]

        anisotropies = [anisotropy.updated(
            site=old_uid_to_new_site[anisotropy.site.unique_id])
            for anisotropy in minimiser.hamiltonian.anisotropies]

        return Hamiltonian(structure, exchanges, anisotropies)

    def updated(self,
                structure: Structure | None = None,
                exchanges: list[Exchange] | None = None,
                anisotropies: list[Anisotropy] | None = None):
        """Create a new Hamiltonian, but with some fields replaced (those not None).

        Parameters
        ----------
        structure : Structure, optional
            Replacement magnetic structure. Default is ``None``.
        exchanges : list of Exchange, optional
            Replacement list of exchanges. Default is ``None``.
        anisotropies : list of Anisotropy, optional
            Replacement list of anisotropies. Default is ``None``.

        Returns
        -------
        Hamiltonian
            New ``Hamiltonian`` instance with the specified fields updated.
        """
        return Hamiltonian(
            self.structure if structure is None else structure,
            self.exchanges if exchanges is None else exchanges,
            self.anisotropies if anisotropies is None else anisotropies)

    @staticmethod
    def _combine_exchanges(exchanges: list[Exchange], swapped_exchanges: list[Exchange]):
        """Combine exchanges together if they have the matching sites and cell offset.

        This might be if they're the same, or swapped.

        Parameters
        ----------
        exchanges : list of Exchange
            Exchanges sharing the same site pair order.
        swapped_exchanges : list of Exchange
            Exchanges with reversed site pair order.

        Returns
        -------
        combined : dict of (tuple of (int, int, int), numpy.ndarray)
            Summed 3x3 exchange matrices keyed by cell offset tuple.
        swapped_combined : dict of (tuple of (int, int, int), numpy.ndarray)
            Summed 3x3 transposed exchange matrices keyed by reversed cell offset tuple.
        """
        by_offset = defaultdict(list)
        swapped_by_offset = defaultdict(list)

        for exchange in exchanges:
            by_offset[exchange.cell_offset.as_tuple].append(exchange.exchange_matrix)
            swapped_by_offset[(-exchange.cell_offset).as_tuple].append(exchange.exchange_matrix.T)

        for exchange in swapped_exchanges:
            swapped_by_offset[exchange.cell_offset.as_tuple].append(exchange.exchange_matrix)
            by_offset[(-exchange.cell_offset).as_tuple].append(exchange.exchange_matrix.T)

        combined = {offset: reduce(np.add, matrices) if matrices else np.zeros((3,3))
                        for offset, matrices in by_offset.items()}

        swapped_combined = {offset: reduce(np.add, matrices) if matrices else np.zeros((3,3))
                                for offset, matrices in swapped_by_offset.items()}

        return combined, swapped_combined


    def symmetry_filled(self) -> "Hamiltonian":
        """Creates a new `Hamiltonian` for which the exchanges and anisotropies are filled out to obey the symmetry.

        Returns
        -------
        Hamiltonian
            New ``Hamiltonian`` with symmetry-equivalent exchanges and anisotropies
            generated from the structure's spacegroup.
        """
        new_exchanges = []
        for exchange in self.exchanges:
            new_exchanges += exchange.symmetry_fill(self.structure, include_original=True)

        new_anisotropies = []
        for anisotropy in self.anisotropies:
            new_anisotropies += anisotropy.symmetry_fill(self.structure, include_original=True)

        return Hamiltonian(self.structure, new_exchanges, new_anisotropies)

    def symmetry_transformed(self, operation: SpaceOperation):
        """Transform the Hamiltonian using this spacegroup.

        If your system is physical this should not do anything to it except change
        the names/colors etc around. Useful for checking things related to symmetry.

        Parameters
        ----------
        operation : SpaceOperation
            Spacegroup symmetry operation to apply to the Hamiltonian.

        Returns
        -------
        Hamiltonian
            Symmetry-transformed ``Hamiltonian`` instance.

        Raises
        ------
        ValueError
            If ``operation`` does not belong to the structure's spacegroup.
        """
        if operation not in self.structure.spacegroup:
            raise ValueError(f"'{operation}' does not belong to spacegroup '{self.structure.spacegroup}'")

        # Transform the sites and build a mapping for exchanges/anisotropies
        unit_cell = self.structure.unit_cell

        xyz_transform = operation.point_operation_in_cartesian(unit_cell)

        site_mapping = dict()
        new_sites = []
        for site in self.structure.sites:
            new_site = site.symmetry_transformed(operation, unit_cell)
            site_mapping[site.unique_id] = new_site
            new_sites.append(new_site)

        # Transform the exchanges
        new_exchanges = []
        for exchange in self.exchanges:
            site_1 = site_mapping[exchange.site_1.unique_id]
            site_2 = site_mapping[exchange.site_2.unique_id]

            new_matrix = xyz_transform @ exchange.exchange_matrix @ xyz_transform.T

            # Try to get the transformed cell offset
            vector = exchange.lattice_vector
            new_vector = operation.point_operation_matrix @ vector

            new_in_cell_vector = site_2.ijk - site_1.ijk

            expected_cell_offset = new_vector - new_in_cell_vector
            new_offset = CellOffset.coerce(expected_cell_offset)

            # # Get the cell offset by using the transformation in cartesian coordinates
            # cartesian_vector = xyz_transform @ exchange.lattice_vector
            # site_difference = unit_cell.lattice_units_to_cartesian(site_2.ijk - site_1.ijk)
            # cell_offset_in_cartesian = cartesian_vector - site_difference
            # cell_offset_vector = unit_cell.cartesian_to_lattice_units(cell_offset_in_cartesian)
            # new_offset = CellOffset.coerce(cell_offset_vector)

            new_exchange = Exchange(site_1, site_2,
                                    cell_offset=new_offset,
                                    exchange_matrix=new_matrix,
                                    name=exchange.name,
                                    metadata=exchange.metadata).specialise()

            new_exchanges.append(new_exchange)

        # Anisotropies
        new_anisotropies = []
        for anisotropy in self.anisotropies:
            new_site = site_mapping[anisotropy.site.unique_id]

            new_matrix = xyz_transform @ anisotropy.anisotropy_matrix @ xyz_transform.T

            new_anisotropy = Anisotropy(site=new_site, anisotropy_matrix=new_matrix)

            new_anisotropies.append(new_anisotropy)

        # Structure
        new_structure = Structure(new_sites,
                                  unit_cell=self.structure.unit_cell,
                                  spacegroup=self.structure.spacegroup,
                                  supercell=self.structure.supercell)

        return Hamiltonian(new_structure, new_exchanges, new_anisotropies)


    def _serialise(self, context: SPWSerialisationContext) -> dict:
        return {"magnetic_structure": self.structure._serialise(context),
                "exchanges": [exchange._serialise(context) for exchange in self.exchanges],
                "anisotropies": [anisotropy._serialise(context) for anisotropy in self.anisotropies]}

    @staticmethod
    @expects_keys("magnetic_structure, exchanges, anisotropies")
    def _deserialise(json: dict, context: SPWDeserialisationContext):
        structure = Structure._deserialise(json["magnetic_structure"], context)
        exchanges = [Exchange._deserialise(exchange, context) for exchange in json["exchanges"]]
        anisotropies = [Anisotropy._deserialise(anisotropy, context) for anisotropy in json["anisotropies"]]

        return Hamiltonian(structure, exchanges, anisotropies)


class HamiltonianParameterization:
    """Parameterisation of a Hamiltonian.

    This is a callable class that returns a Hamiltonian with exchanges set by
    specified parameters. Calling an instance with ``*parameters`` returns the
    ``Hamiltonian`` with those parameter values set.

    Parameters
    ----------
    hamiltonian : Hamiltonian
        Base Hamiltonian to parameterize.
    *parameters : ParametrizationType
        Parameter specifications identifying exchange or anisotropy attributes to vary.
    find_ground_state_with : dict, optional
        Keyword arguments passed to :meth:`Hamiltonian.ground_state` when evaluating
        the parameterized Hamiltonian. Default is ``None``.

    Raises
    ------
    ValueError
        If multiple parameters are assigned to the same exchange or anisotropy
        attribute.
    TypeError
        If a target exchange or anisotropy does not have the specified parameter.
    """

    def __init__(self,
                 hamiltonian: Hamiltonian,
                 *parameters: ParametrizationType,
                 find_ground_state_with: dict | None = None):

        self._hamiltonian = hamiltonian
        self._find_ground_state = find_ground_state_with is not None
        self._ground_state_parameters = {} if find_ground_state_with is None else find_ground_state_with

        # Create a list of parameters that will be updated
        base_exchange_parameters: list[list[tuple[Exchange, str]]] = []
        base_anisotropy_parameters: list[list[tuple[Anisotropy, str]]] = []

        for param in parameters:
            exchanges, anisotropies = _regularise_parameters(hamiltonian, param)

            base_exchange_parameters.append(exchanges)
            base_anisotropy_parameters.append(anisotropies)

        # Check that there is no conflicts, this means that each parameter is only set by only one entry
        # Basically, we can just check for duplicates

        multicounts = [item for item, count in Counter(sum(base_exchange_parameters, [])).items() if count > 1]
        if len(multicounts) > 0:
            raise ValueError(f"Multiple parameters assigned to the same exchange parameter {multicounts}")

        multicounts = [item for item, count in Counter(sum(base_anisotropy_parameters, [])).items() if count > 1]
        if len(multicounts) > 0:
            raise ValueError(f"Multiple parameters assigned to the same anisotropy parameter {multicounts}")

        # Check that the exchanges have the required parameters
        for parameter_definition in base_exchange_parameters:
            for target, attribute in parameter_definition:
                if attribute not in target.parameters:
                    valid_parameters = ", ".join(target.parameters)
                    raise TypeError(f"{target} does not have parameter '{attribute}', it has: {valid_parameters}")


        # Check that the anisotropies have the required parameters
        for parameter_definition in base_anisotropy_parameters:
            for target, attribute in parameter_definition:
                if attribute not in target.scalar_parameters:
                    valid_parameters = ", ".join(target.scalar_parameters)
                    raise TypeError(f"{target} does not have parameter '{attribute}', it has: {valid_parameters}")

        # Convert the exchange to index in the list of exchanges
        exchange_unique_id_to_index = {exchange.unique_id: index
                                       for index, exchange in enumerate(hamiltonian.exchanges)}
        self._exchange_parameter_definitions: list[list[tuple[int, str]]] = []

        for parameter_definition in base_exchange_parameters:
            indexed_parameter_definition: list[tuple[int, str]] = []
            for target, attribute in parameter_definition:
                index = exchange_unique_id_to_index[target.unique_id]
                indexed_parameter_definition.append((index, attribute))
            self._exchange_parameter_definitions.append(indexed_parameter_definition)

        # Convert the anisotropy to index for the list of anisotropies
        anisotropy_unique_id_to_index = {anisotropy.unique_id: index
                                       for index, anisotropy in enumerate(hamiltonian.anisotropies)}
        self._anisotropy_parameter_definitions: list[list[tuple[int, str]]] = []

        for parameter_definition in base_anisotropy_parameters:
            indexed_parameter_definition: list[tuple[int, str]] = []
            for target, attribute in parameter_definition:
                index = anisotropy_unique_id_to_index[target.unique_id]
                indexed_parameter_definition.append((index, attribute))
            self._anisotropy_parameter_definitions.append(indexed_parameter_definition)

        # Number is useful
        self._n_parameters = len(self._exchange_parameter_definitions)

        assert len(self._anisotropy_parameter_definitions) == len(self._exchange_parameter_definitions), \
            "Should both be length n_parameters"

    @staticmethod
    def _legend_entry(exchange_name, parameter_name):
        """Format a legend entry from an exchange name and parameter name.

        Parameters
        ----------
        exchange_name : str or None
            Name of the exchange or anisotropy term.
        parameter_name : str
            Name of the parameter attribute.

        Returns
        -------
        str
            Formatted legend label.
        """
        if exchange_name is None or exchange_name == "":
            return parameter_name
        else:
            return exchange_name + "." + parameter_name

    def energy_plot(self,
                    parameter_values: ArrayLike,
                    path: Path,
                    field: ArrayLike | None = None,
                    show: bool = True,
                    colormap_name: str = 'jet',
                    new_figure: bool = True,
                    show_legend=True,
                    use_rust: bool = True):
        """Show a plot of the energies.

        Parameters
        ----------
        parameter_values : array_like
            1D or 2D array of parameter values at which to evaluate and plot the
            Hamiltonian energies.
        path : Path
            Path in reciprocal space along which to calculate energies.
        field : array_like, optional
            External magnetic field vector in tesla. Default is ``None``.
        show : bool, optional
            Whether to display the plot with ``plt.show()``. Default is ``True``.
        colormap_name : str, optional
            Name of the Matplotlib colormap used to colour the curves. Default is
            ``'jet'``.
        new_figure : bool, optional
            Whether to create a new figure. Default is ``True``.
        show_legend : bool, optional
            Whether to display a legend on the plot. Default is ``True``.
        use_rust : bool, optional
            Whether to use the Rust calculator. Default is ``True``.

        Raises
        ------
        ValueError
            If the second dimension of ``parameter_values`` does not match the
            number of parameterized variables.
        """
        # Check/regularise input values
        parameter_values = np.array(parameter_values)
        if len(parameter_values.shape) == 1:
            parameter_values = parameter_values.reshape(-1, 1)

        if parameter_values.shape[1] != self._n_parameters:
            raise ValueError("Second dimension size of parameter_values should match number of parameters")

        n_curves = parameter_values.shape[0]

        #
        # Do the plotting
        #

        # Colours
        try:
            cmap = plt.get_cmap(colormap_name)
        except ValueError as ve:
            logger.warning(str(ve))
            cmap = plt.get_cmap('jet')

        colors = cmap(np.linspace(0, 1, n_curves+2)[1:-1]) # Generally a bit nicer if we avoid the endpoints

        # Figure
        if new_figure:
            fig = plt.figure("Energy")
        else:
            fig = plt.gcf()

        x_values = path.x_values()

        for i in range(n_curves):
            ham = self(*parameter_values[i, :])
            first = True
            for series in ham.sorted_positive_energies(path, field=field, use_rust=use_rust):
                if first:
                    label = ", ".join([f"{value:.3g}" for value in parameter_values[i, :]])
                    plt.plot(x_values, series, color=colors[i], label=label)
                    first=False
                else:
                    plt.plot(x_values, series, color=colors[i])

        if show_legend:
            plt.legend(loc="upper right")

        # Format the plot
        path.format_plot(plt)

        if show:
            plt.show()
        else:
            return fig



    def __call__(self, *parameters: float) -> Hamiltonian:  # noqa: D102
        if len(parameters) != self._n_parameters:
            raise ValueError(f"Expected {self._n_parameters} parameters, got {len(parameters)}")

        # Updated exchanges
        new_exchanges = [exchange for exchange in self._hamiltonian.exchanges]
        for parameter_definition, value in zip(self._exchange_parameter_definitions, parameters):
            for (exchange_index, attribute) in parameter_definition:
                new_exchanges[exchange_index] = new_exchanges[exchange_index].updated(**{attribute: value})

        # Updated anisotropies
        new_anisotropies = [anisotropy for anisotropy in self._hamiltonian.anisotropies]
        for parameter_definition, value in zip(self._anisotropy_parameter_definitions, parameters):
            for anisotropy_index, attribute in parameter_definition:
                new_anisotropies[anisotropy_index] = new_anisotropies[anisotropy_index].updated(**{attribute: value})

        # Return new hamiltonian, optimise ground state if needed
        new_hamiltonian = Hamiltonian(self._hamiltonian.structure, new_exchanges, new_anisotropies)
        if self._find_ground_state:
            return new_hamiltonian.ground_state(**self._ground_state_parameters)
        else:
            return new_hamiltonian

    def __repr__(self):
        parts = []
        for index, (exchanges, anisotropies) in enumerate(zip(self._exchange_parameter_definitions,
                                                              self._anisotropy_parameter_definitions)):

            exchange_parts = [f"{self._hamiltonian.exchanges[index].name}.{parameter}"
                                for index, parameter in exchanges]

            anisotropy_parts = [f"{self._hamiltonian.anisotropies[index]}.{parameter}"
                                for index, parameter in anisotropies]

            data = ", ".join(exchange_parts + anisotropy_parts)

            parts.append(f"argument_{index} -> {data}")
        s = "; ".join(parts)

        return f"HamiltonianParameterization({s})"
