"""Symmetry module."""
