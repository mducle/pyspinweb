"""Information/structures around symmetry state."""

from dataclasses import dataclass

from pyspinw.symmetry.group import SpaceGroup
from pyspinw.symmetry.magnetic_group import MagneticSpaceGroup
from pyspinw.symmetry.unitcell import UnitCell


class SymmetrySettings:
    """Object to hold symmetry information together.

    Parameters
    ----------
    space_group : SpaceGroup
        Crystallographic space group.
    magnetic_group : MagneticSpaceGroup
        Magnetic space group.
    unit_cell : UnitCell
        Crystal unit cell.
    """

    def __init__(self, space_group: SpaceGroup, magnetic_group: MagneticSpaceGroup, unit_cell: UnitCell):

        self._space_group = space_group
        self._magnetic_group = magnetic_group
        self._unit_cell = unit_cell

    @property
    def space_group(self):
        """Space group associated with the symmetry settings."""
        return self._space_group

    @property
    def magnetic_group(self):
        """Magnetic space group associated with the symmetry settings."""
        return self._magnetic_group

    @property
    def unit_cell(self):
        """Unit cell associated with the symmetry settings."""
        return self._unit_cell
#
# DEFAULT_SYMMETRY = SymmetrySettings(
#     space_group=spacegroup_symbol_lookup["P 1"],
#     magnetic_group=magnetic_group_symbol_lookup["P1.1"],
#     unit_cell=UnitCell(1,1,1)
# )
