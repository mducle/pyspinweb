"""Reads TB2J output files and returns Hamiltonian object."""
import pickle
import numpy as np
import ase
import re
import spglib
import pathlib
from numpy._typing import ArrayLike
from pyspinw.symmetry.unitcell import UnitCell
from pyspinw.site import Site
from pyspinw.exchange import Exchange, HeisenbergExchange
from pyspinw.structure import Structure
from pyspinw.hamiltonian import Hamiltonian
from pyspinw.tolerances import tolerances

# Reg-ex to parse TB2J text files, which are split into 3 sections:
# * A cell description which is a 3x3 matrix beginning with the string "Cell (Angstrom):"
# * An 8-column table of atomic positions/moments and ID starting with "Atoms:"
#   - The columns are: ID(text), 3xpositions(floats), Charge(float), 3xmoments(floats)
# * For each bond a new section with a 9-column header and then separate sections:
#   - "J_iso:" (single float); "DMI:" (3-vector); and "J_ani:" (3x3 matrix)
#   - The header is: i-site-ID, j-site-ID, normalized-inter-site-vector, Jiso,
#     full-inter-site-vector, distance - this is the "JPOS_EXPR" reg-ex
# There are two types of TB2J outputs: collinear and non-collinear
# * In collinear calculations only J_iso is given and the site-moments is a single float
# * In non-collinear calcs, J_iso, DMI and J_ani are given and site-moments are 3-vectors
CELL_EXPR = ''.join([r'Cell \(Angstrom\):\s*'] + [r'([\-\d\.]*)\s*']*9)
ATOMS_EXPR = ''.join([r'^(\w*)\s*'] + [r'([\-\d\.]*)\s*']*7)
JPOS_EXPR = r'----\s*\n\s*([A-Za-z0-9]*)\s*([A-Za-z0-9]*)\s*\(\s*([\-\d]*),\s*([\-\d]*),\s*([\-\d]*)\)' \
                        r'\s*([\d\-\.]*)\s*\(\s*([\-\d\.]*),\s*([\-\d\.]*),\s*([\-\d\.]*)\)\s*([\d\-\.]*)'
JISO_EXPR = r'J_iso:\s*([\d\-\.]*)\s*$'
JDMI_EXPR = r'DMI:\s*\(\s*([\d\-\.]*)\s*([\d\-\.]*)\s*([\d\-\.]*)\)\s*$'
JANI_EXPR = r'J_ani:\s*$\s*\[\[\s*([\d\-\.]*)\s*([\d\-\.]*)\s*([\d\-\.]*)\s*\]\s*$' \
                        r'\s*\[\s*([\d\-\.]*)\s*([\d\-\.]*)\s*([\d\-\.]*)\s*\]\s*$' \
                        r'\s*\[\s*([\d\-\.]*)\s*([\d\-\.]*)\s*([\d\-\.]*)\s*\]\]\s*$'

class _sym_index:
    """Helper class to generate atom ID indices from element string.

    Attributes
    ----------
    syms : dict
        Mapping from chemical symbol to the current count of atoms of that
        element.
    """

    def __init__(self):
        self.syms = {}
    def __call__(self, sym: str):
        self.syms[sym] = (self.syms[sym] + 1) if sym in self.syms else 1
        return sym + str(self.syms[sym])


class _coupling:
    """Helper class to use list comprehension to determine duplicated reverse couplings.

    Parameters
    ----------
    s1 : str
        Identifier of the first site in the bond.
    s2 : str
        Identifier of the second site in the bond.
    icv : array_like
        Inter-cell lattice vector connecting ``s1`` and ``s2``.

    Attributes
    ----------
    s1 : str
        Identifier of the first site in the bond.
    s2 : str
        Identifier of the second site in the bond.
    icv : numpy.ndarray
        Inter-cell lattice vector connecting ``s1`` and ``s2``.
    """

    def __init__(self, s1, s2, icv):
        self.s1, self.s2, self.icv = s1, s2, np.array(icv)
    def __eq__(self, other):
        return self.s1 == other.s1 and self.s2 == other.s2 and np.sum(np.abs(self.icv - other.icv)) < 1e-8
    def __neg__(self):
        return _coupling(self.s2, self.s1, -self.icv)


class TB2J_Input:
    """Handles input from TB2J and conversion to Hamiltonian object.

    Parameters
    ----------
    filename : pathlib.Path or str or None, optional
        Path to a TB2J ``exchange.out`` text file or ``TB2J.pickle`` file.
        Default is ``None``.

    Attributes
    ----------
    type : str or None
        Format of the loaded TB2J data (``"text"``, ``"pickle"``, or ``None``).
    data : str or dict or None
        Raw contents loaded from the TB2J input.
    """

    type = None
    data = None

    def __init__(self, filename: pathlib.Path | str | None = None):
        if filename is not None:
            self.file = str(filename)
            if self.file.endswith('pickle'):
                with open(filename, 'rb') as f:
                    self._parse_pickle(pickle.load(f))
            else:
                with open(filename, 'r') as f:
                    self._parse_text(f.read())

    def _parse_text(self, text: str):
        """Parse the contents of a TB2J ``exchange.out`` text file.

        Parameters
        ----------
        text : str
            Raw text content of a TB2J ``exchange.out`` file.

        Raises
        ------
        RuntimeError
            If required section headers are missing or if exchange counts are
            inconsistent.
        """
        self.type, self.data = ('text', text)
        if not all([kw in self.data for kw in ['Cell (Angstrom):', 'Atoms:', 'Exchange:']]):
            raise RuntimeError('Could not find one of the required keys, "Cell", "Atoms", or "Exchange"')
        cell_re = re.search(CELL_EXPR, self.data)
        cell = np.array([float(cell_re.group(i)) for i in range(1,10)]).reshape(3,3)
        atoms_re = re.finditer(ATOMS_EXPR, self.data.split('Atoms:')[1].split('Total')[0], re.MULTILINE)
        self.atoms, syms, pos, magmoms = [], [], [], []
        for at in atoms_re:
            if at.group(5):
                magmoms.append(np.array(list(map(float, at.groups()[5:8]))) if at.group(8) else float(at.group(6)))
                self.atoms.append(at.group(1))
                syms.append(re.match(r'([A-Za-z]{1,2})', at.group(1)).group(1))
                pos.append(tuple(map(float, at.groups()[1:4])))
        exch_txt = self.data.split('Exchange:')[1]
        self.j_pos = [[v[0], v[1], list(map(int, v[2:5])), float(v[5]), list(map(float, v[6:9]))]
                      for v in re.findall(JPOS_EXPR, exch_txt)]
        self.j_iso = np.array(list(map(float, re.findall(JISO_EXPR, exch_txt, re.MULTILINE))))
        self.j_dmi = np.array([list(map(float, v)) for v in re.findall(JDMI_EXPR, exch_txt, re.MULTILINE)])
        self.j_ani = np.array([np.array(list(map(float, v))).reshape(3,3)
                               for v in re.findall(JANI_EXPR, exch_txt, re.MULTILINE)])
        self.noncolinear = False
        if len(np.shape(magmoms)) > 1:
            self.noncolinear = True
            if self.j_iso.shape[0] != self.j_dmi.shape[0] or self.j_iso.shape[0] != self.j_ani.shape[0]:
                raise RuntimeError("Inconsistent number of exchanges")
        assert len(self.j_pos) == len(self.j_iso), "Inconsistent number of exchanges"
        # Checks for atoms which have no exchanges defined and zeros their moments so they don't enter the LSW calc
        mag_atoms = set([jp[0] for jp in self.j_pos])
        for non_mag_id in [i for i in range(len(self.atoms)) if self.atoms[i] not in mag_atoms]:
            magmoms[non_mag_id] = magmoms[non_mag_id] * 0  # Handle both scalar and vector (non-coll) cases
        self.struct = ase.Atoms(cell=cell, symbols=syms, positions=pos, magmoms=magmoms)

    def _parse_pickle(self, data: dict):
        """Parse a dictionary loaded from a ``TB2J.pickle`` file.

        Parameters
        ----------
        data : dict
            Unpickled dictionary containing TB2J structure and exchange data.
        """
        self.type, self.data = ('pickle', data)
        self.noncolinear = not self.data['colinear']
        if self.noncolinear:
            magmoms = self.data['spinat']
        else:
            magmoms = self.data['magmoms']
        self.struct = self.data['atoms']
        sym_index = _sym_index()
        self.atoms = [sym_index(sym) for sym in self.struct.get_chemical_symbols()]
        d_exch, d_dist = (self.data[k] for k in ['exchange_Jdict', 'distance_dict'])
        ord_k = [k for k, v in d_dist.items() if k in d_exch]
        ord_k = [ord_k[i] for i in np.argsort([v[1] for k, v in d_dist.items() if k in d_exch])]
        # ind_atoms is the list of magnetic atoms which have non-zero exchanges. Set other moments to zero
        if 'ind_atoms' in self.data:
            idmap = self.data['ind_atoms']
        else:
            # Assume that the index order is the same as the order of atoms but ignore those atoms without exchanges
            idmap = {i:i for i in set([k[1] for k in ord_k])}
        for non_mag_id in [i for i in range(len(self.atoms)) if i not in idmap.values()]:
            magmoms[non_mag_id] = magmoms[non_mag_id] * 0
        # Determines the list of couplings in the file, labelled by site-i, site-j, normalised inter-site vector
        #   the J_iso value, full inter-site vector and distance in Angstrom
        self.j_pos = [[self.atoms[idmap[k[1]]], self.atoms[idmap[k[2]]], k[0], 1000*d_exch[k],
                       d_dist[k][0], d_dist[k][1]] for k in ord_k]
        self.struct.set_initial_magnetic_moments(magmoms)
        # TB2J stores different types of exchanges in separate variables:
        #   J_iso (Heisenberg) is present for all files, DMI and J_ani are only in "non-colinear" files
        self.j_iso, self.j_dmi, self.j_ani = ([1000*d_exch[k] for k in ord_k], [], [])
        if self.noncolinear:
            self.j_dmi = [1000*self.data['dmi_ddict'][k] for k in ord_k]
            self.j_ani = [1000*self.data['Jani_dict'][k] for k in ord_k]

    def _get_symmetrized_structure(self, pos: ArrayLike, moms: ArrayLike, precision: float=1e-5):
        """Obtain the symmetrized unit cell, positions, and magnetic moments.

        Parameters
        ----------
        pos : array_like
            Fractional atomic positions.
        moms : array_like
            Atomic magnetic moments.
        precision : float, optional
            Symmetry search precision. Default is ``1e-5``.

        Raises
        ------
        NotImplementedError
            Always raised as symmetry reduction is not yet implemented.
        """
        raise NotImplementedError()

    @classmethod
    def from_exchange_out(cls, filename: pathlib.Path | str):
        """Read input from an exchange.out TB2J file.

        Parameters
        ----------
        filename : pathlib.Path or str
            Path to an ``exchange.out`` TB2J file.

        Returns
        -------
        TB2J_Input or None
            Parsed TB2J input instance.
        """
        obj = cls()
        with open(filename, 'r') as f:
            obj._parse_text(f.read())
        obj.file = str(filename)
        return obj

    @classmethod
    def from_text(cls, text: str):
        """Read input from text string containing the contents of an exchange.out TB2J file.

        Parameters
        ----------
        text : str
            Raw text content of an ``exchange.out`` TB2J file.

        Returns
        -------
        TB2J_Input or None
            Parsed TB2J input instance.
        """
        obj = cls()
        obj.file = None
        obj._parse_text(text)
        return obj

    @classmethod
    def from_pickle(cls, filename: pathlib.Path | str):
        """Read input from a TB2J.pickle file.

        Parameters
        ----------
        filename : pathlib.Path or str
            Path to a ``TB2J.pickle`` file.

        Returns
        -------
        TB2J_Input or None
            Parsed TB2J input instance.
        """
        obj = cls()
        with open(filename, 'rb') as f:
            return obj._parse_pickle(pickle.load(f))
        obj.file = str(filename)
        return obj

    def to_hamiltonian(self, symmetrize: bool=False):
        """Create a SpinW Hamiltonian object from the TB2J inputs.

        Parameters
        ----------
        symmetrize : bool, optional
            Whether to symmetrize the crystal structure before building the
            Hamiltonian. Default is ``False``.

        Returns
        -------
        Hamiltonian
            Constructed SpinW Hamiltonian object.
        """
        # ASE and TB2J uses moments in uB; SpinW wants it as spin length S where mu = g*S
        pos, moms = self.struct.get_scaled_positions(), self.struct.get_initial_magnetic_moments() / 2
        if symmetrize:
            unitcell, pos, moms = self._get_symmetrized_structure(pos, moms)
        else:
            unitcell = UnitCell(*tuple(self.struct.get_cell().cellpar()))
        # Calculates the inter-cell vector from the inter-site vector given by TB2J
        vec = unitcell.cartesian_to_lattice_units(np.array([p[4] for p in self.j_pos]))
        idx = {n:i for i, n in enumerate(self.atoms)}
        ijvec = [tuple(map(int, np.floor((pos[idx[p[0]]] + dv)+0.01))) for p, dv in zip(self.j_pos, vec)]
        # TB2J lists every pair i->j and j->i whereas SpinW implicitly calculates the reversed j->i
        # so we need to remove these otherwise it will be double counted
        couplings = [_coupling(p[0], p[1], ijv) for p, ijv in zip(self.j_pos, ijvec)]
        idx = [(i1,i2+i1+1) for i1, c1 in enumerate(couplings) for i2, c2 in enumerate(couplings[i1+1:]) if c1 == -c2]
        # TB2J uses the convention that spins a normalised so a TB2J exchange = J*SiSJ - need scale this out
        # TB2J also follows the opposite sign convention to SpinW so we have a negative here
        mm = [np.linalg.norm(m) for m in moms]
        jf = {f'{self.atoms[i1]}{self.atoms[i2]}':-mm[i1]*mm[i2] for i1 in range(len(mm)) for i2 in range(len(mm))}
        # Now construct the Hamiltonian
        def _DM(dv):
            return np.array([[0, dv[2], dv[1]], [-dv[2], 0, dv[0]], [-dv[1], -dv[0], 0]])
        exchanges = []
        if self.noncolinear:
            s = {n:Site(*tuple(p), *tuple(m), name=n) for p, m, n in zip(pos, moms, self.atoms)}
            for i1, i2 in idx:
                p, j, v = self.j_pos[i1], (self.j_iso[i1] + self.j_iso[i2]) / 2., ijvec[i1]
                ani, dm = (self.j_ani[i1] + self.j_ani[i2]) / 2., (self.j_dmi[i1] + self.j_dmi[i2]) / 2.
                exch_mat = np.eye(3) * j + ani + _DM(dm)
                if np.linalg.norm(exch_mat) > tolerances.EXCHANGE_ORDER_THRESHOLD:
                    exchanges.append(Exchange(s[p[0]], s[p[1]], v, exch_mat / jf[f'{p[0]}{p[1]}']))
        else:
            s = {n:Site(p[0], p[1], p[2], 0, 0, m, name=n) for p, m, n in zip(pos, moms, self.atoms)}
            for i1, i2 in idx:
                p, j, v = self.j_pos[i1], (self.j_iso[i1] + self.j_iso[i2]) / 2., ijvec[i1]
                if abs(j) > tolerances.EXCHANGE_ORDER_THRESHOLD:
                    exchanges.append(HeisenbergExchange(s[p[0]], s[p[1]], j / jf[f'{p[0]}{p[1]}'], v))
        return Hamiltonian(Structure([s[k] for k in self.atoms], unitcell), exchanges)


if __name__ == '__main__':
    import sys
    sp = TB2J_Input(sys.argv[1])
    hamiltonian = sp.to_hamiltonian()
    hamiltonian.print_summary()
    from pyspinw.path import Path
    path = Path([[0,0,1], [0.5,0.5,1], [0.5,0.5,0.5], [1,1,0.5], [1,1,0]])
    import matplotlib.pyplot as plt
    fig = hamiltonian.spaghetti_plot(path, show=False, use_rotating=False)
    plt.show()
